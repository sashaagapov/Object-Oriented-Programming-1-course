var interfacelab4agapov__v3_1_1_i_person =
[
    [ "DisplayInfo", "interfacelab4agapov__v3_1_1_i_person.html#a4843c4d5ee34ac3cc376194f356496bc", null ],
    [ "Name", "interfacelab4agapov__v3_1_1_i_person.html#a390a4b5dba9fbe6b405c8c8716c53d07", null ],
    [ "SubjectName", "interfacelab4agapov__v3_1_1_i_person.html#a2dd838a52fe9d69ca0f8112074862a36", null ]
];