var dir_142a6ba5034caf9b94510091e90c1d58 =
[
    [ ".NETCoreApp,Version=v10.0.AssemblyAttributes.cs", "_8_n_e_t_core_app_00_version_0av10_80_8_assembly_attributes_8cs.html", null ],
    [ "LAB_3.AssemblyInfo.cs", "_l_a_b__3_8_assembly_info_8cs.html", null ],
    [ "LAB_4_V4.AssemblyInfo.cs", "_l_a_b__4___v4_8_assembly_info_8cs.html", null ]
];