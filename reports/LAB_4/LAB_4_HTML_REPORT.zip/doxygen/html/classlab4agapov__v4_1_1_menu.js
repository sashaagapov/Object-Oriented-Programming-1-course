var classlab4agapov__v4_1_1_menu =
[
    [ "PrintOptions", "classlab4agapov__v4_1_1_menu.html#a5b7696f3a7ad88d38ddcf9af678f27c8", null ],
    [ "ReadCommand", "classlab4agapov__v4_1_1_menu.html#addad63e7f8cfa6fcd6ffb41e73817f71", null ]
];