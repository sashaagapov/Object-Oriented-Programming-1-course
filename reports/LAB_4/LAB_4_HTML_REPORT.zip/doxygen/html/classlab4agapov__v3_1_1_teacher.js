var classlab4agapov__v3_1_1_teacher =
[
    [ "Teacher", "classlab4agapov__v3_1_1_teacher.html#add31ba31252d58a6fcf2e5f090241d21", null ],
    [ "Teacher", "classlab4agapov__v3_1_1_teacher.html#a98ff24f3c9bda6d19838030bbdf9fa3b", null ],
    [ "Teacher", "classlab4agapov__v3_1_1_teacher.html#a107835609ca13ee9b91d9dade03931aa", null ],
    [ "ChangeStudyHours", "classlab4agapov__v3_1_1_teacher.html#a4e330f04ce8aed91134b62333b5932c4", null ],
    [ "DecreaseStudents", "classlab4agapov__v3_1_1_teacher.html#a37dcfdb9bd530554da19fed74910e93b", null ],
    [ "DisplayInfo", "classlab4agapov__v3_1_1_teacher.html#a7da121c96914695a81d88e2100ee4fd5", null ],
    [ "GetInfo", "classlab4agapov__v3_1_1_teacher.html#a62e0b5928d028f5fe53d6a595c80525e", null ],
    [ "GiveMaterial", "classlab4agapov__v3_1_1_teacher.html#a5aabc3d771243e9a69869e1186a91376", null ],
    [ "GradeStudent", "classlab4agapov__v3_1_1_teacher.html#a3025a3aadffb04154401f2e5462b5c80", null ],
    [ "IncreaseStudents", "classlab4agapov__v3_1_1_teacher.html#af888871f5ac05b1ebb4a65fbb6fcb597", null ],
    [ "WriteGradeToJournal", "classlab4agapov__v3_1_1_teacher.html#a78b3e4c7c4e4f54f61614fcb715cc1d8", null ],
    [ "gradesJournal", "classlab4agapov__v3_1_1_teacher.html#ab6025d87d697c64929403575fe70e060", null ],
    [ "quantityOfStudents", "classlab4agapov__v3_1_1_teacher.html#ac3b14a7a62c42cfde763207f413d5d81", null ],
    [ "studyHours", "classlab4agapov__v3_1_1_teacher.html#a43eafaffd6c7e260107d5765a2dfc68c", null ],
    [ "studyMaterial", "classlab4agapov__v3_1_1_teacher.html#a448a6af52cf7a0826040532ca7681c32", null ],
    [ "GradesJournal", "classlab4agapov__v3_1_1_teacher.html#a3ec3e60f63771d454c5f44dfb0705358", null ],
    [ "QuantityOfStudents", "classlab4agapov__v3_1_1_teacher.html#a7bec79331d498acfd81807bf39ddc68d", null ],
    [ "StudyHours", "classlab4agapov__v3_1_1_teacher.html#add5d467c785379995572b4775f8b4aa0", null ],
    [ "StudyMaterial", "classlab4agapov__v3_1_1_teacher.html#a1d1a79163dd3d479da746c88049ce89c", null ],
    [ "TeacherName", "classlab4agapov__v3_1_1_teacher.html#afedad8d539d2bde52fcfc504ab9641eb", null ]
];