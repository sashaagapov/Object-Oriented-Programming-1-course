var searchData=
[
  ['datatoprocess_0',['DataToProcess',['../classlab4agapov__v4_1_1_service.html#a276c8eb465925beb61c51c813d8bed33',1,'lab4agapov_v4::Service']]],
  ['datatoprocess_1',['dataToProcess',['../classlab4agapov__v4_1_1_service.html#a7d2d664b190151174dd256cbd337787a',1,'lab4agapov_v4::Service']]],
  ['decreasestudents_2',['DecreaseStudents',['../classlab4agapov__v4_1_1_teacher.html#afd94c7daeee3923de10a90a096ef73aa',1,'lab4agapov_v4::Teacher']]],
  ['downloadedmaterial_3',['DownloadedMaterial',['../classlab4agapov__v4_1_1_student.html#ac1423dc26c0bc51d82341f089908a15a',1,'lab4agapov_v4::Student']]],
  ['downloadedmaterial_4',['downloadedMaterial',['../classlab4agapov__v4_1_1_student.html#ad8afd5089eb40cef0446d20945cc7936',1,'lab4agapov_v4::Student']]],
  ['downloadmaterial_5',['DownloadMaterial',['../classlab4agapov__v4_1_1_student.html#a5f78604343006827144d0c537d18b625',1,'lab4agapov_v4::Student']]]
];
