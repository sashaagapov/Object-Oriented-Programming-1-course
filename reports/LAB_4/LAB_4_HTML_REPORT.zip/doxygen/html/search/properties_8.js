var searchData=
[
  ['studentname_0',['StudentName',['../classlab4agapov__v4_1_1_student.html#aa4a1c9b94b174b16e11c4c7788a268d0',1,'lab4agapov_v4::Student']]],
  ['studyhours_1',['StudyHours',['../classlab4agapov__v4_1_1_teacher.html#af549f96fdabde95c7e09dd5a96d47be1',1,'lab4agapov_v4::Teacher']]],
  ['studymaterial_2',['StudyMaterial',['../classlab4agapov__v4_1_1_teacher.html#aaa0aacaac105f5b923cc46c971373636',1,'lab4agapov_v4::Teacher']]],
  ['subjectname_3',['SubjectName',['../interfacelab4agapov__v4_1_1_i_person.html#a40d6a42664c02c826f6a158867f458c7',1,'lab4agapov_v4.IPerson.SubjectName'],['../classlab4agapov__v4_1_1_person.html#aeef933fdf2728e1e132f28944a2083bf',1,'lab4agapov_v4.Person.SubjectName']]]
];
