var searchData=
[
  ['getenumerator_0',['GetEnumerator',['../classlab4agapov__v4_1_1_student_group.html#aeebf53b3e4c9ea9778c710fbb69e1649',1,'lab4agapov_v4::StudentGroup']]],
  ['getinfo_1',['GetInfo',['../classlab4agapov__v4_1_1_person.html#abcb43488a702d2dd6200f2ec2a86e27d',1,'lab4agapov_v4.Person.GetInfo()'],['../classlab4agapov__v4_1_1_student.html#a87148f95daff0682dc3f87332992e671',1,'lab4agapov_v4.Student.GetInfo()'],['../classlab4agapov__v4_1_1_teacher.html#a1170e2727f92bf7d002d29735553159f',1,'lab4agapov_v4.Teacher.GetInfo()']]],
  ['givematerial_2',['GiveMaterial',['../classlab4agapov__v4_1_1_teacher.html#a6cc0b7d09776521c5700486f3988eb81',1,'lab4agapov_v4::Teacher']]],
  ['givematerialtostudentfrominput_3',['GiveMaterialToStudentFromInput',['../classlab4agapov__v4_1_1_teacher.html#ab1d88012edc7d4886f06c9fcd28b4ba6',1,'lab4agapov_v4::Teacher']]],
  ['gradestudent_4',['GradeStudent',['../classlab4agapov__v4_1_1_teacher.html#a784cdb38abf9c2bee502e1969c5fa83e',1,'lab4agapov_v4::Teacher']]],
  ['gradestudentfrominput_5',['GradeStudentFromInput',['../classlab4agapov__v4_1_1_teacher.html#ac06e7197bcf23c2c8ff7aebd29fabf00',1,'lab4agapov_v4::Teacher']]]
];
