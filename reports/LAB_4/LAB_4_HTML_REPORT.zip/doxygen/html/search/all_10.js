var searchData=
[
  ['tasksdone_0',['TasksDone',['../classlab4agapov__v4_1_1_student.html#a5f9d1c012eb39c8a4cea6e2b2248f1a0',1,'lab4agapov_v4::Student']]],
  ['tasksdone_1',['tasksDone',['../classlab4agapov__v4_1_1_student.html#a659cf66aca58ae5f9c47acec26346dac',1,'lab4agapov_v4::Student']]],
  ['teacher_2',['Teacher',['../classlab4agapov__v4_1_1_teacher.html',1,'lab4agapov_v4.Teacher'],['../classlab4agapov__v4_1_1_teacher.html#a4e6245c4f8afed416bfee9a181c23a4d',1,'lab4agapov_v4.Teacher.Teacher()'],['../classlab4agapov__v4_1_1_teacher.html#a0968b3c255863c38fd3325238b9f9dbe',1,'lab4agapov_v4.Teacher.Teacher(string teacherName, string subjectName, int studyHours, int quantityOfStudents, string gradesJournal, string studyMaterial)'],['../classlab4agapov__v4_1_1_teacher.html#adec8d8a2ef195cf6592fd3b08071c13b',1,'lab4agapov_v4.Teacher.Teacher(Teacher other)']]],
  ['teacher_2ecs_3',['Teacher.cs',['../_teacher_8cs.html',1,'']]],
  ['teachername_4',['TeacherName',['../classlab4agapov__v4_1_1_teacher.html#a321a570daac567636f29e563e7e599f1',1,'lab4agapov_v4::Teacher']]]
];
