var searchData=
[
  ['teacher_0',['Teacher',['../classlab4agapov__v4_1_1_teacher.html#a4e6245c4f8afed416bfee9a181c23a4d',1,'lab4agapov_v4.Teacher.Teacher()'],['../classlab4agapov__v4_1_1_teacher.html#a0968b3c255863c38fd3325238b9f9dbe',1,'lab4agapov_v4.Teacher.Teacher(string teacherName, string subjectName, int studyHours, int quantityOfStudents, string gradesJournal, string studyMaterial)'],['../classlab4agapov__v4_1_1_teacher.html#adec8d8a2ef195cf6592fd3b08071c13b',1,'lab4agapov_v4.Teacher.Teacher(Teacher other)']]]
];
