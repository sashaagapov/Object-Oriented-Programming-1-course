var searchData=
[
  ['tasksdone_0',['tasksDone',['../classlab4agapov__v4_1_1_student.html#a659cf66aca58ae5f9c47acec26346dac',1,'lab4agapov_v4::Student']]]
];
