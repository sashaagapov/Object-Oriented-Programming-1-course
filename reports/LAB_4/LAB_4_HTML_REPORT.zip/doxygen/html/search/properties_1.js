var searchData=
[
  ['datatoprocess_0',['DataToProcess',['../classlab4agapov__v4_1_1_service.html#a276c8eb465925beb61c51c813d8bed33',1,'lab4agapov_v4::Service']]],
  ['downloadedmaterial_1',['DownloadedMaterial',['../classlab4agapov__v4_1_1_student.html#ac1423dc26c0bc51d82341f089908a15a',1,'lab4agapov_v4::Student']]]
];
