var searchData=
[
  ['name_0',['Name',['../interfacelab4agapov__v4_1_1_i_person.html#aec13933f3999ab705cfa525e46177019',1,'lab4agapov_v4.IPerson.Name'],['../classlab4agapov__v4_1_1_person.html#aa92a3b50f881434b33a354e3c54a5c09',1,'lab4agapov_v4.Person.Name']]],
  ['name_1',['name',['../classlab4agapov__v4_1_1_person.html#a103cdf325c4e019401a7869ddcc192e7',1,'lab4agapov_v4::Person']]]
];
