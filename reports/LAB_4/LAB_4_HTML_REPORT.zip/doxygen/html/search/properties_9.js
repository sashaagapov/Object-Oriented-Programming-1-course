var searchData=
[
  ['tasksdone_0',['TasksDone',['../classlab4agapov__v4_1_1_student.html#a5f9d1c012eb39c8a4cea6e2b2248f1a0',1,'lab4agapov_v4::Student']]],
  ['teachername_1',['TeacherName',['../classlab4agapov__v4_1_1_teacher.html#a321a570daac567636f29e563e7e599f1',1,'lab4agapov_v4::Teacher']]]
];
