var searchData=
[
  ['viewgrades_0',['ViewGrades',['../classlab4agapov__v4_1_1_student.html#a73bc0967484c1a90e0c4cd258ef4f72f',1,'lab4agapov_v4::Student']]]
];
