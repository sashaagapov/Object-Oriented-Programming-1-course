var searchData=
[
  ['increasestudents_0',['IncreaseStudents',['../classlab4agapov__v4_1_1_teacher.html#addec75904f521f36cc0bcfb9069eeb31',1,'lab4agapov_v4::Teacher']]],
  ['iperson_1',['IPerson',['../interfacelab4agapov__v4_1_1_i_person.html',1,'lab4agapov_v4']]],
  ['iperson_2ecs_2',['IPerson.cs',['../_i_person_8cs.html',1,'']]]
];
