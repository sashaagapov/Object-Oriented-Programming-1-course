var searchData=
[
  ['position_0',['position',['../classlab4agapov__v4_1_1_student_group_enumerator.html#a62306e156ac89cccc4362cf37a214631',1,'lab4agapov_v4::StudentGroupEnumerator']]],
  ['protocol_1',['protocol',['../classlab4agapov__v4_1_1_service.html#a30d33c7795a67c6d72250cf24f0191cd',1,'lab4agapov_v4::Service']]]
];
