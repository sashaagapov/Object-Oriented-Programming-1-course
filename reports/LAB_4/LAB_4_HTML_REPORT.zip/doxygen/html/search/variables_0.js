var searchData=
[
  ['datatoprocess_0',['dataToProcess',['../classlab4agapov__v4_1_1_service.html#a7d2d664b190151174dd256cbd337787a',1,'lab4agapov_v4::Service']]],
  ['downloadedmaterial_1',['downloadedMaterial',['../classlab4agapov__v4_1_1_student.html#ad8afd5089eb40cef0446d20945cc7936',1,'lab4agapov_v4::Student']]]
];
