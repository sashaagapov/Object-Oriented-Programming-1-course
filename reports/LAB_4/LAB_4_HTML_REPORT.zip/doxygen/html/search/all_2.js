var searchData=
[
  ['buildgrouptext_0',['BuildGroupText',['../classlab4agapov__v4_1_1_teacher.html#a37bf0f5a893e8b1e0475943b6e6edb1d',1,'lab4agapov_v4::Teacher']]],
  ['buildreport_1',['BuildReport',['../classlab4agapov__v4_1_1_teacher.html#a4fb7ad2d2afa8110f1bb2f33dcfaf526',1,'lab4agapov_v4::Teacher']]]
];
