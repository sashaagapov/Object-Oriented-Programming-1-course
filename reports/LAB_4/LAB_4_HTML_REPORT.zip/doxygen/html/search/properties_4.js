var searchData=
[
  ['name_0',['Name',['../interfacelab4agapov__v4_1_1_i_person.html#aec13933f3999ab705cfa525e46177019',1,'lab4agapov_v4.IPerson.Name'],['../classlab4agapov__v4_1_1_person.html#aa92a3b50f881434b33a354e3c54a5c09',1,'lab4agapov_v4.Person.Name']]]
];
