var searchData=
[
  ['decreasestudents_0',['DecreaseStudents',['../classlab4agapov__v4_1_1_teacher.html#afd94c7daeee3923de10a90a096ef73aa',1,'lab4agapov_v4::Teacher']]],
  ['downloadmaterial_1',['DownloadMaterial',['../classlab4agapov__v4_1_1_student.html#a5f78604343006827144d0c537d18b625',1,'lab4agapov_v4::Student']]]
];
