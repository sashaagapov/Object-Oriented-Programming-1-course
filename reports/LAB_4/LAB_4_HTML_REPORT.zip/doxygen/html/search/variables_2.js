var searchData=
[
  ['gradesjournal_0',['gradesJournal',['../classlab4agapov__v4_1_1_teacher.html#ad26fa1795eb914f134597f06722089dd',1,'lab4agapov_v4::Teacher']]],
  ['gradeslist_1',['gradesList',['../classlab4agapov__v4_1_1_student.html#a0ca997a6a76e60ffe2a74fd826dfa5c7',1,'lab4agapov_v4::Student']]]
];
