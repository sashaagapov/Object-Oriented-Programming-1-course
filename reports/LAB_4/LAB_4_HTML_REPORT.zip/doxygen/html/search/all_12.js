var searchData=
[
  ['writegradetojournal_0',['WriteGradeToJournal',['../classlab4agapov__v4_1_1_teacher.html#afe758b0cee82633582890a4197b7065f',1,'lab4agapov_v4::Teacher']]],
  ['writetofile_1',['WriteToFile',['../classlab4agapov__v4_1_1_service.html#a41fb67ce37ef1291883c27e337ea812e',1,'lab4agapov_v4::Service']]]
];
