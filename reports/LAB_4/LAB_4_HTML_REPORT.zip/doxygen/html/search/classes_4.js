var searchData=
[
  ['teacher_0',['Teacher',['../classlab4agapov__v4_1_1_teacher.html',1,'lab4agapov_v4']]]
];
