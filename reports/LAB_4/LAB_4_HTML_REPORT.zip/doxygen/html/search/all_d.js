var searchData=
[
  ['quantityofstudents_0',['QuantityOfStudents',['../classlab4agapov__v4_1_1_teacher.html#a119db5c10f4326cbc9f4e7b398fa5099',1,'lab4agapov_v4::Teacher']]],
  ['quantityofstudents_1',['quantityOfStudents',['../classlab4agapov__v4_1_1_teacher.html#a943ff328ea6059177a5a7e65dc9aefe0',1,'lab4agapov_v4::Teacher']]]
];
