var searchData=
[
  ['person_0',['Person',['../classlab4agapov__v4_1_1_person.html',1,'lab4agapov_v4']]],
  ['program_1',['Program',['../classlab4agapov__v4_1_1_program.html',1,'lab4agapov_v4']]]
];
