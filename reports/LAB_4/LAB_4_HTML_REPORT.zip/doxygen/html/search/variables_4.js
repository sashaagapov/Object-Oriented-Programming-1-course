var searchData=
[
  ['name_0',['name',['../classlab4agapov__v4_1_1_person.html#a103cdf325c4e019401a7869ddcc192e7',1,'lab4agapov_v4::Person']]]
];
