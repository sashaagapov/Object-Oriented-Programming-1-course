var searchData=
[
  ['addgrade_0',['AddGrade',['../classlab4agapov__v4_1_1_student.html#a73b1bcceeb2b8b50bd46615c13d8e331',1,'lab4agapov_v4::Student']]],
  ['addstudent_1',['AddStudent',['../classlab4agapov__v4_1_1_student_group.html#af798e6ea858ba424d75c70515d8c0ef6',1,'lab4agapov_v4::StudentGroup']]],
  ['appendprotocol_2',['AppendProtocol',['../classlab4agapov__v4_1_1_service.html#a97ae4bfa8022900051003f78cb1a12ce',1,'lab4agapov_v4::Service']]]
];
