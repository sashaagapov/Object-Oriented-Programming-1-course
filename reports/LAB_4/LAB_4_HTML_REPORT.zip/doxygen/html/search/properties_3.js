var searchData=
[
  ['gradesjournal_0',['GradesJournal',['../classlab4agapov__v4_1_1_teacher.html#aa33ebbcda0c7fd3f6d87254c27a1b699',1,'lab4agapov_v4::Teacher']]],
  ['gradeslist_1',['GradesList',['../classlab4agapov__v4_1_1_student.html#a1203f3c20b96b60831688ae827b3bc06',1,'lab4agapov_v4::Student']]]
];
