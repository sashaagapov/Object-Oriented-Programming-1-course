var searchData=
[
  ['iperson_0',['IPerson',['../interfacelab4agapov__v4_1_1_i_person.html',1,'lab4agapov_v4']]]
];
