var classlab4agapov__v3_1_1_person =
[
    [ "Person", "classlab4agapov__v3_1_1_person.html#a595a3e8f7ee23aafc82044a30d649a80", null ],
    [ "Person", "classlab4agapov__v3_1_1_person.html#a76f36834ccd18a479c1aef7f2290c047", null ],
    [ "Person", "classlab4agapov__v3_1_1_person.html#ad99f96bc54b40a5f37fbd7599eabee7f", null ],
    [ "DisplayInfo", "classlab4agapov__v3_1_1_person.html#a70fb1a1990af90b3765257bbc131a5c1", null ],
    [ "GetInfo", "classlab4agapov__v3_1_1_person.html#a9ffb71a2717e63b67e89300814b751fc", null ],
    [ "name", "classlab4agapov__v3_1_1_person.html#a5f85f97e170e4c1950aadd2111309aa5", null ],
    [ "subjectName", "classlab4agapov__v3_1_1_person.html#a2cbe55c5464b294e97888940b2cef038", null ],
    [ "Name", "classlab4agapov__v3_1_1_person.html#a1cb387ba7460a72b8adea92d61cd1b52", null ],
    [ "SubjectName", "classlab4agapov__v3_1_1_person.html#af776c569f56f18bd59bb5658276e4965", null ]
];