var classlab4agapov__v1_1_1_program =
[
    [ "Main", "classlab4agapov__v1_1_1_program.html#aa2292a34ae2e4e77d7f7a5f5135d0b34", null ]
];