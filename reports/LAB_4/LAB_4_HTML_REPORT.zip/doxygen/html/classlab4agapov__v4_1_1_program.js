var classlab4agapov__v4_1_1_program =
[
    [ "Main", "classlab4agapov__v4_1_1_program.html#ad667bee17415a39c23ebfa4c3c41980b", null ]
];