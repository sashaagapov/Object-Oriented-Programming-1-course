var classlab4agapov__v3_1_1_menu =
[
    [ "Menu", "classlab4agapov__v3_1_1_menu.html#a2b37d358715ab0edc54c9d9597e5a616", null ],
    [ "Menu", "classlab4agapov__v3_1_1_menu.html#afbe64c03f35044710073010d22559321", null ],
    [ "Menu", "classlab4agapov__v3_1_1_menu.html#ac3aa5a90a986c51efee90935441c8e84", null ],
    [ "ChangeTeacherHours", "classlab4agapov__v3_1_1_menu.html#a5a1f47cba12d576f14e5566421a34fd2", null ],
    [ "DecreaseStudents", "classlab4agapov__v3_1_1_menu.html#a5d42950795d3b48fbfc1cc2d6a7f85d7", null ],
    [ "GiveMaterialToStudent", "classlab4agapov__v3_1_1_menu.html#a56b52da3145b05e34316e93f149e2d26", null ],
    [ "GradeStudent", "classlab4agapov__v3_1_1_menu.html#a3b3c5b447ba4d17bc7ccdb30322bb0a5", null ],
    [ "IncreaseStudents", "classlab4agapov__v3_1_1_menu.html#aeb87e9343bfa7549162026f17d4c64e7", null ],
    [ "ReadNotEmptyText", "classlab4agapov__v3_1_1_menu.html#aeff19e320cb1f3baa00843a1d672eae3", null ],
    [ "ReadNumberInRange", "classlab4agapov__v3_1_1_menu.html#a5b200c11a9dbd953485f374496b0a10e", null ],
    [ "Run", "classlab4agapov__v3_1_1_menu.html#acc3805dcdee80b0960f69f84d34e6807", null ],
    [ "SaveData", "classlab4agapov__v3_1_1_menu.html#a9a12f40f7647ce9bf8a82386cea1fac7", null ],
    [ "ShowInformation", "classlab4agapov__v3_1_1_menu.html#a8051577cb6726cdf50daef626fe18dc9", null ],
    [ "service", "classlab4agapov__v3_1_1_menu.html#a81a480540abaca01e3660c3597d20c61", null ],
    [ "student", "classlab4agapov__v3_1_1_menu.html#a24ef903b885967805f490b539b6c29fa", null ],
    [ "teacher", "classlab4agapov__v3_1_1_menu.html#ac7d3dd002f5d8fb21a96c78d4d96cbdb", null ]
];