var classlab4agapov__v2_1_1_teacher =
[
    [ "Teacher", "classlab4agapov__v2_1_1_teacher.html#ab9d578469a1f9448ea5e30a93bd0d74d", null ],
    [ "Teacher", "classlab4agapov__v2_1_1_teacher.html#a4d633917770727d39716c144a2a25e7c", null ],
    [ "Teacher", "classlab4agapov__v2_1_1_teacher.html#ac1c0f9011b99ed23fef38e8ad0a1c015", null ],
    [ "ChangeStudyHours", "classlab4agapov__v2_1_1_teacher.html#af40b46b406d26f3ade099c916859d1e7", null ],
    [ "DecreaseStudents", "classlab4agapov__v2_1_1_teacher.html#aa4aa8e6fc5abf02038febc60ede38591", null ],
    [ "GiveMaterial", "classlab4agapov__v2_1_1_teacher.html#a7a29d86e4001fdecda08da4e8ed9ace7", null ],
    [ "GradeStudent", "classlab4agapov__v2_1_1_teacher.html#a8e6a1fb4baf7c103e9c8d6446e2353cc", null ],
    [ "IncreaseStudents", "classlab4agapov__v2_1_1_teacher.html#ab9421c6aa1a427f118a97edb57c1926b", null ],
    [ "WriteGradeToJournal", "classlab4agapov__v2_1_1_teacher.html#a84075ab481bfd7f283faf073e511e874", null ],
    [ "gradesJournal", "classlab4agapov__v2_1_1_teacher.html#a56dc64d85415f5426a36fdeb50fce4ef", null ],
    [ "quantityOfStudents", "classlab4agapov__v2_1_1_teacher.html#ab796ab95e8e0022494ae0753814382a5", null ],
    [ "studyHours", "classlab4agapov__v2_1_1_teacher.html#ac2f22c9b5b0c5a2b62008aa7ec87d4a5", null ],
    [ "studyMaterial", "classlab4agapov__v2_1_1_teacher.html#ab3f127a222eba80a731f9b39e6c163bb", null ],
    [ "GradesJournal", "classlab4agapov__v2_1_1_teacher.html#a0b740b36587fb5dd18d43e3dd49a5745", null ],
    [ "QuantityOfStudents", "classlab4agapov__v2_1_1_teacher.html#adc9dd940933489f6e764d3f753c82ae2", null ],
    [ "StudyHours", "classlab4agapov__v2_1_1_teacher.html#a7fc4bd2a0aaf504a5cf8a323e568c53e", null ],
    [ "StudyMaterial", "classlab4agapov__v2_1_1_teacher.html#aa20b0996f9d264c9de9d742d3682bad8", null ],
    [ "TeacherName", "classlab4agapov__v2_1_1_teacher.html#a0ac5a5524e9f37b558812693e32475f3", null ]
];