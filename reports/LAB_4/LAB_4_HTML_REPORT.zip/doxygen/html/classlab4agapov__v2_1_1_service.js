var classlab4agapov__v2_1_1_service =
[
    [ "Service", "classlab4agapov__v2_1_1_service.html#ae0f0a4b8b67be03cfea11b1d5be95f93", null ],
    [ "Service", "classlab4agapov__v2_1_1_service.html#a6d3d9eb812d74a647289fb36cbd7784e", null ],
    [ "Service", "classlab4agapov__v2_1_1_service.html#aabcc7388d6c9a7b48dbf6669a9e36183", null ],
    [ "PrintAndSave", "classlab4agapov__v2_1_1_service.html#a2afe0e66695f6a31e9cdf73b21104ffb", null ],
    [ "PrintToConsole", "classlab4agapov__v2_1_1_service.html#a41586aca1440b11fa59c3b4aad28a0c2", null ],
    [ "ReadFromConsole", "classlab4agapov__v2_1_1_service.html#ac2d8913588e50af459929067a1e3343b", null ],
    [ "ReadFromFile", "classlab4agapov__v2_1_1_service.html#a4743554be0efc475155489c46ddf005b", null ],
    [ "SaveProtocolToFile", "classlab4agapov__v2_1_1_service.html#a6fa75acb4d6609f84d0095493ccaf223", null ],
    [ "SaveReport", "classlab4agapov__v2_1_1_service.html#a2ada4e6706d280c482df40ccbeecb9ec", null ],
    [ "dataToProcess", "classlab4agapov__v2_1_1_service.html#aa0bfa0c44ce11b02b29e1c2e0918a236", null ],
    [ "filePath", "classlab4agapov__v2_1_1_service.html#ac8ce5f2ce0854a6af8dbbc23fd61f975", null ],
    [ "outputFormat", "classlab4agapov__v2_1_1_service.html#a81303e82981bef86cfbdafdbdffe01e8", null ],
    [ "protocol", "classlab4agapov__v2_1_1_service.html#af14cc3b39476f94b36c21a6ec06a03d9", null ],
    [ "DataToProcess", "classlab4agapov__v2_1_1_service.html#a01db797485aeae743af2d714518ce3c0", null ],
    [ "FilePath", "classlab4agapov__v2_1_1_service.html#a7623d6d8ea163d5e552b8d3b23463134", null ],
    [ "OutputFormat", "classlab4agapov__v2_1_1_service.html#a055d0beed400cfc14a527716e9f6c05c", null ]
];