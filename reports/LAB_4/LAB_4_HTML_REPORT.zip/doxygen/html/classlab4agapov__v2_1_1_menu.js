var classlab4agapov__v2_1_1_menu =
[
    [ "Menu", "classlab4agapov__v2_1_1_menu.html#a89ae2be524d8bb2d939d63945302378d", null ],
    [ "Menu", "classlab4agapov__v2_1_1_menu.html#a5316340c5ce91eadfe36e631f414ec5b", null ],
    [ "Menu", "classlab4agapov__v2_1_1_menu.html#a4a2a9d33d037f7dd6a3e69191ab28b39", null ],
    [ "ChangeTeacherHours", "classlab4agapov__v2_1_1_menu.html#a9cc51648ff8cd3fd729c83e0ab37c1a9", null ],
    [ "DecreaseStudents", "classlab4agapov__v2_1_1_menu.html#a5f71c06b1f8bc9d307625b9637fa009b", null ],
    [ "GiveMaterialToStudent", "classlab4agapov__v2_1_1_menu.html#abee6015e012b1e964dee096cf015a46c", null ],
    [ "GradeStudent", "classlab4agapov__v2_1_1_menu.html#a0116f4b6a0ef326a4fbb9f6ddacb6348", null ],
    [ "IncreaseStudents", "classlab4agapov__v2_1_1_menu.html#ae70360474a13cb95ee40cebe33350f4e", null ],
    [ "ReadNotEmptyText", "classlab4agapov__v2_1_1_menu.html#a32e51630e48e4d66b7b243606cf24fab", null ],
    [ "ReadNumberInRange", "classlab4agapov__v2_1_1_menu.html#a5eb43f1b3e987d3879cf75641b48c234", null ],
    [ "Run", "classlab4agapov__v2_1_1_menu.html#a0d280bd672d3068b9833f25b668ad728", null ],
    [ "SaveData", "classlab4agapov__v2_1_1_menu.html#af056596abf9f78e3e3718802ba9971b9", null ],
    [ "ShowInformation", "classlab4agapov__v2_1_1_menu.html#a6dac2e05c498cb67dcebf2193e8315ed", null ],
    [ "service", "classlab4agapov__v2_1_1_menu.html#aeaa44b5d4ceebdd565e9fd1b0466a966", null ],
    [ "student", "classlab4agapov__v2_1_1_menu.html#aa4cffc01fb7b8fbcd37383823487956b", null ],
    [ "teacher", "classlab4agapov__v2_1_1_menu.html#a47a70dec4813fd98e96f24789b4a5be4", null ]
];