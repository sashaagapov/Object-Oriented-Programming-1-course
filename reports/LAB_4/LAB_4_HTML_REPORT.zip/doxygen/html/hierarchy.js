var hierarchy =
[
    [ "ICloneable", null, [
      [ "lab4agapov_v4.Student", "classlab4agapov__v4_1_1_student.html", null ],
      [ "lab4agapov_v4.StudentGroup", "classlab4agapov__v4_1_1_student_group.html", null ]
    ] ],
    [ "IComparable", null, [
      [ "lab4agapov_v4.Student", "classlab4agapov__v4_1_1_student.html", null ]
    ] ],
    [ "IComparer", null, [
      [ "lab4agapov_v4.StudentTasksComparer", "classlab4agapov__v4_1_1_student_tasks_comparer.html", null ]
    ] ],
    [ "IEnumerable", null, [
      [ "lab4agapov_v4.StudentGroup", "classlab4agapov__v4_1_1_student_group.html", null ]
    ] ],
    [ "IEnumerator", null, [
      [ "lab4agapov_v4.StudentGroupEnumerator", "classlab4agapov__v4_1_1_student_group_enumerator.html", null ]
    ] ],
    [ "lab4agapov_v4.IPerson", "interfacelab4agapov__v4_1_1_i_person.html", [
      [ "lab4agapov_v4.Person", "classlab4agapov__v4_1_1_person.html", [
        [ "lab4agapov_v4.Student", "classlab4agapov__v4_1_1_student.html", null ],
        [ "lab4agapov_v4.Teacher", "classlab4agapov__v4_1_1_teacher.html", null ]
      ] ]
    ] ],
    [ "lab4agapov_v4.Menu", "classlab4agapov__v4_1_1_menu.html", null ],
    [ "lab4agapov_v4.Program", "classlab4agapov__v4_1_1_program.html", null ],
    [ "lab4agapov_v4.Service", "classlab4agapov__v4_1_1_service.html", null ]
];