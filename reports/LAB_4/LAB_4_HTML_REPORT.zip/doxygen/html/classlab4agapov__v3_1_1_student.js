var classlab4agapov__v3_1_1_student =
[
    [ "Student", "classlab4agapov__v3_1_1_student.html#a1531eba9346a11b7fabd9e49ec2cdf56", null ],
    [ "Student", "classlab4agapov__v3_1_1_student.html#a1dee26f8237de4fbdff8237a6161cefd", null ],
    [ "Student", "classlab4agapov__v3_1_1_student.html#acca25f6a14dd51ce8fde69cc27bad891", null ],
    [ "AddGrade", "classlab4agapov__v3_1_1_student.html#a56509fa6ae0bb61708da37af1636a406", null ],
    [ "CalculateRating", "classlab4agapov__v3_1_1_student.html#abb4b3b1161a42b10767dbbd2b0cef66c", null ],
    [ "DisplayInfo", "classlab4agapov__v3_1_1_student.html#af20f9ba431072f3c041e02514e29b6fb", null ],
    [ "DownloadMaterial", "classlab4agapov__v3_1_1_student.html#ad759a3953345f97433ce3524c56092c7", null ],
    [ "GetInfo", "classlab4agapov__v3_1_1_student.html#aa98eb8b8e715b759ac68a2ba56426769", null ],
    [ "ViewGrades", "classlab4agapov__v3_1_1_student.html#ae092d2cdb5258639375dfdd528bc5450", null ],
    [ "downloadedMaterial", "classlab4agapov__v3_1_1_student.html#aecc5e9746bfec00441a053e77ba97ee4", null ],
    [ "gradesList", "classlab4agapov__v3_1_1_student.html#a611262450e5e416141e2540de7a008e3", null ],
    [ "rating", "classlab4agapov__v3_1_1_student.html#aad2a7498661a86062dd0ec4c30e5a7aa", null ],
    [ "tasksDone", "classlab4agapov__v3_1_1_student.html#a99f4c1703e37655ed76d1d74f6f1c9a7", null ],
    [ "DownloadedMaterial", "classlab4agapov__v3_1_1_student.html#a98e347eaa2ef22d14bdcd40b4cc337fd", null ],
    [ "GradesList", "classlab4agapov__v3_1_1_student.html#afde21177e2f57165b0f8b6cadfb0462d", null ],
    [ "Rating", "classlab4agapov__v3_1_1_student.html#a23a638cc61b35f54e28af465fe8458c4", null ],
    [ "StudentName", "classlab4agapov__v3_1_1_student.html#a1add324a2bdf6d9190c0c1ab196ade8d", null ],
    [ "TasksDone", "classlab4agapov__v3_1_1_student.html#a713ee47b891410f2c89e1cb97c2a5c48", null ]
];