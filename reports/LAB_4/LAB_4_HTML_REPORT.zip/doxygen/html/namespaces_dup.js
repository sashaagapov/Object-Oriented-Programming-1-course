var namespaces_dup =
[
    [ "lab4agapov_v4", "namespacelab4agapov__v4.html", "namespacelab4agapov__v4" ]
];