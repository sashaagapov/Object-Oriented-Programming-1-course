var _teacher_8cs =
[
    [ "lab4agapov_v4.Teacher", "classlab4agapov__v4_1_1_teacher.html", "classlab4agapov__v4_1_1_teacher" ]
];