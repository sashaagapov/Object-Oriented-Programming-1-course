var files_dup =
[
    [ "obj", "dir_43724e81dd40e09f32417973865cdd64.html", "dir_43724e81dd40e09f32417973865cdd64" ],
    [ "IPerson.cs", "_i_person_8cs.html", "_i_person_8cs" ],
    [ "Menu.cs", "_menu_8cs.html", "_menu_8cs" ],
    [ "Person.cs", "_person_8cs.html", "_person_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "Service.cs", "_service_8cs.html", "_service_8cs" ],
    [ "Student.cs", "_student_8cs.html", "_student_8cs" ],
    [ "StudentGroup.cs", "_student_group_8cs.html", "_student_group_8cs" ],
    [ "StudentGroupEnumerator.cs", "_student_group_enumerator_8cs.html", "_student_group_enumerator_8cs" ],
    [ "StudentTasksComparer.cs", "_student_tasks_comparer_8cs.html", "_student_tasks_comparer_8cs" ],
    [ "Teacher.cs", "_teacher_8cs.html", "_teacher_8cs" ]
];