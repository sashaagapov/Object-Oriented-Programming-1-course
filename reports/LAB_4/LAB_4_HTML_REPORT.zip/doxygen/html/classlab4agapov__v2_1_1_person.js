var classlab4agapov__v2_1_1_person =
[
    [ "Person", "classlab4agapov__v2_1_1_person.html#a4fd942362a953fd513ee5495d0f7f69c", null ],
    [ "Person", "classlab4agapov__v2_1_1_person.html#a0400c1e1e331b2cdf904e1e899a32a29", null ],
    [ "Person", "classlab4agapov__v2_1_1_person.html#ab430fba44eb6a7c88268197e7edf91b1", null ],
    [ "name", "classlab4agapov__v2_1_1_person.html#ab10dd35fd22e08ef26f5225d9dcd4e20", null ],
    [ "subjectName", "classlab4agapov__v2_1_1_person.html#a67b59e11134d55d0f6c1c867164360b4", null ],
    [ "Name", "classlab4agapov__v2_1_1_person.html#a1400678bbdd6cfca6366ba762984b8f3", null ],
    [ "SubjectName", "classlab4agapov__v2_1_1_person.html#a03e282c5f759f5dfac7c491c05c5e262", null ]
];