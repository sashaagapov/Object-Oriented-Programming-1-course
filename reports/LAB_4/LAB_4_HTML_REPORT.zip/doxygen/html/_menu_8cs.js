var _menu_8cs =
[
    [ "lab4agapov_v4.Menu", "classlab4agapov__v4_1_1_menu.html", "classlab4agapov__v4_1_1_menu" ]
];