var classlab4agapov__v3_1_1_program =
[
    [ "Main", "classlab4agapov__v3_1_1_program.html#a0ec876eeb4fc97c5641afa492b82094b", null ]
];