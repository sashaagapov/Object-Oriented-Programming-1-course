var classlab4agapov__v4_1_1_service =
[
    [ "Service", "classlab4agapov__v4_1_1_service.html#adcb9e11e852fbbb0fd3d02429d4b1e70", null ],
    [ "Service", "classlab4agapov__v4_1_1_service.html#ad6ee0f6bf64a456d3f6cd03667ccbee7", null ],
    [ "Service", "classlab4agapov__v4_1_1_service.html#aa40453de92b2c1253ae0cb394e4001a2", null ],
    [ "AppendProtocol", "classlab4agapov__v4_1_1_service.html#a97ae4bfa8022900051003f78cb1a12ce", null ],
    [ "PrintToConsole", "classlab4agapov__v4_1_1_service.html#aeda750f4416423be869dc1853696c8dd", null ],
    [ "ReadFromConsole", "classlab4agapov__v4_1_1_service.html#ac6105d287bd4cce2b8a17d58de1cca24", null ],
    [ "ReadFromFile", "classlab4agapov__v4_1_1_service.html#acdc1a4be5b8af187b923e1c26eb23bb7", null ],
    [ "SaveProtocolToFile", "classlab4agapov__v4_1_1_service.html#aa84212301da7e4094fa1dc6e2045247e", null ],
    [ "WriteToFile", "classlab4agapov__v4_1_1_service.html#a41fb67ce37ef1291883c27e337ea812e", null ],
    [ "dataToProcess", "classlab4agapov__v4_1_1_service.html#a7d2d664b190151174dd256cbd337787a", null ],
    [ "filePath", "classlab4agapov__v4_1_1_service.html#a471598374cc7e4a628a4945da55897d7", null ],
    [ "outputFormat", "classlab4agapov__v4_1_1_service.html#a9d65b71ac9e0b34ddede818435165268", null ],
    [ "protocol", "classlab4agapov__v4_1_1_service.html#a30d33c7795a67c6d72250cf24f0191cd", null ],
    [ "DataToProcess", "classlab4agapov__v4_1_1_service.html#a276c8eb465925beb61c51c813d8bed33", null ],
    [ "FilePath", "classlab4agapov__v4_1_1_service.html#ad3accdde6ee3cb711774124af2822994", null ],
    [ "OutputFormat", "classlab4agapov__v4_1_1_service.html#a5f62f8b2e9f66017390b653879744afb", null ]
];