var _student_8cs =
[
    [ "lab4agapov_v4.Student", "classlab4agapov__v4_1_1_student.html", "classlab4agapov__v4_1_1_student" ]
];