var classlab4agapov__v3_1_1_service =
[
    [ "Service", "classlab4agapov__v3_1_1_service.html#a03d8c2a7dcf426a023143297e54a9bd4", null ],
    [ "Service", "classlab4agapov__v3_1_1_service.html#a59b65f3b549170e6cc02a9f00ef80cfa", null ],
    [ "Service", "classlab4agapov__v3_1_1_service.html#a06571c2ff04b972c88175fec9bcc976f", null ],
    [ "PrintAndSave", "classlab4agapov__v3_1_1_service.html#acfd20212a0d2642e59351e89badefccf", null ],
    [ "PrintToConsole", "classlab4agapov__v3_1_1_service.html#a81440125525fa994e084d62d46e70f51", null ],
    [ "ReadFromConsole", "classlab4agapov__v3_1_1_service.html#adc447fe0de4421b22cf0a03a588f79cb", null ],
    [ "ReadFromFile", "classlab4agapov__v3_1_1_service.html#a46b1195a0bcc91a4a1edb768510b0596", null ],
    [ "SaveProtocolToFile", "classlab4agapov__v3_1_1_service.html#a82549506debdf9a8d66f919b01903845", null ],
    [ "SaveReport", "classlab4agapov__v3_1_1_service.html#a3d36fcdfb5e026be5face4766d5f5c30", null ],
    [ "dataToProcess", "classlab4agapov__v3_1_1_service.html#adc03696d3c1acd4ce553b3f81ac71393", null ],
    [ "filePath", "classlab4agapov__v3_1_1_service.html#a72fe83da3218b53c022d3271f7e9da1d", null ],
    [ "outputFormat", "classlab4agapov__v3_1_1_service.html#afc102a4a262b2b8f3a0fc015fe572002", null ],
    [ "protocol", "classlab4agapov__v3_1_1_service.html#a774b92bbbf41a48d4a1015222cfbd0cf", null ],
    [ "DataToProcess", "classlab4agapov__v3_1_1_service.html#a9ddd62122e3448b7c18e1f22664fa45b", null ],
    [ "FilePath", "classlab4agapov__v3_1_1_service.html#a6d98b37159c5e5bc113a6aec2dbb4265", null ],
    [ "OutputFormat", "classlab4agapov__v3_1_1_service.html#a7c644e4be6b5d4b792cb99a1c50cfaf4", null ]
];