var _person_8cs =
[
    [ "lab4agapov_v4.Person", "classlab4agapov__v4_1_1_person.html", "classlab4agapov__v4_1_1_person" ]
];