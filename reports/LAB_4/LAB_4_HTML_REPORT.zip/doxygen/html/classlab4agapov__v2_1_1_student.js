var classlab4agapov__v2_1_1_student =
[
    [ "Student", "classlab4agapov__v2_1_1_student.html#a51561aa8c30970c2bf5667475c069522", null ],
    [ "Student", "classlab4agapov__v2_1_1_student.html#a29655bfc4d990dd6722bcaa92420f743", null ],
    [ "Student", "classlab4agapov__v2_1_1_student.html#a9d17b7637788562dab84cff3b3dbedf1", null ],
    [ "AddGrade", "classlab4agapov__v2_1_1_student.html#a33f6d504a6a5c0465dcfb1ec3e57b3bf", null ],
    [ "CalculateRating", "classlab4agapov__v2_1_1_student.html#adb542a702fb24d5bc7e5a676f2092819", null ],
    [ "DownloadMaterial", "classlab4agapov__v2_1_1_student.html#a492796ef5d1dd2569c57fe9611e00e2b", null ],
    [ "ViewGrades", "classlab4agapov__v2_1_1_student.html#a462b2675eebd757f44621d0e5ef16d03", null ],
    [ "downloadedMaterial", "classlab4agapov__v2_1_1_student.html#a334f99955ee0a56e5d1d5ae2614b7304", null ],
    [ "gradesList", "classlab4agapov__v2_1_1_student.html#a0b39ac38d1defea73a770c58b6cbe20a", null ],
    [ "rating", "classlab4agapov__v2_1_1_student.html#a34857e9c2a5c7abbda70b04faecdcab0", null ],
    [ "tasksDone", "classlab4agapov__v2_1_1_student.html#aec612e76f5507bc7380d8c3092206b2a", null ],
    [ "DownloadedMaterial", "classlab4agapov__v2_1_1_student.html#af74921cb23ea3fd2dc53fb11722f07c5", null ],
    [ "GradesList", "classlab4agapov__v2_1_1_student.html#a0ddd364e6dc6245115eb578d5c75b5d3", null ],
    [ "Rating", "classlab4agapov__v2_1_1_student.html#a9c35c9930781534752a5a54aaf558cd2", null ],
    [ "StudentName", "classlab4agapov__v2_1_1_student.html#ab993b9a661e4745d4239819a86b87785", null ],
    [ "TasksDone", "classlab4agapov__v2_1_1_student.html#a96d7fdb39fd27734f841ff8eb3cbed96", null ]
];