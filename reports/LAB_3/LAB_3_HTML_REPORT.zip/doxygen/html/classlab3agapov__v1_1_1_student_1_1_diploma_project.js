var classlab3agapov__v1_1_1_student_1_1_diploma_project =
[
    [ "DiplomaProject", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a64a6e3fe987ba27ae841d3bdededdfac", null ],
    [ "DiplomaProject", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a41329f84251f7e027a4053306c214593", null ],
    [ "DiplomaProject", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#abf7fbb0ad558715a08acf589ae132982", null ],
    [ "ChooseTheme", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8150d8709e4ad905cc320a6e3959ff4d", null ],
    [ "DetermineComplexity", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#ab0befeb0bb057fb39a71c4b568429d6c", null ],
    [ "DetermineGrade", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8cbea4ecfab604935a48c09d85f64ce3", null ],
    [ "grade", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a88bef95cbb7556f7fed072e95423b6a9", null ],
    [ "methodsCount", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#ad83ab41df2af5a44dc1ba198bc59a1da", null ],
    [ "supervisorName", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#acf2ce39ac78c0dd47e51cef7aa9c87a4", null ],
    [ "themeComplexity", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a47c291e456d464193ddc8ca25ef089f8", null ],
    [ "themeName", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#ac48311ab3a3806c4a06219199230e69c", null ],
    [ "Grade", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a014a74c12dec78c7dc5a13f4d6b1db69", null ],
    [ "MethodsCount", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#ae13cc5c03946097c10dd13b37aa2c8f3", null ],
    [ "SupervisorName", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8807438a7e831dc488fdf3e379f2b3f2", null ],
    [ "ThemeComplexity", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a7f82e51d4ba4b3ef6ff1ec8fa243573c", null ],
    [ "ThemeName", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a508f70ca41567007f9d842a2c05fc431", null ]
];