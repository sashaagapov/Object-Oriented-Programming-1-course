var dir_71f022fe2dd74154929bf7c771f18800 =
[
    [ "Menu.cs", "_l_a_b__3___v4_2_menu_8cs.html", "_l_a_b__3___v4_2_menu_8cs" ],
    [ "Program.cs", "_l_a_b__3___v4_2_program_8cs.html", "_l_a_b__3___v4_2_program_8cs" ],
    [ "ScientificPaper.cs", "_scientific_paper_8cs.html", "_scientific_paper_8cs" ],
    [ "Service.cs", "_l_a_b__3___v4_2_service_8cs.html", "_l_a_b__3___v4_2_service_8cs" ],
    [ "Student.cs", "_l_a_b__3___v4_2_student_8cs.html", "_l_a_b__3___v4_2_student_8cs" ],
    [ "StudentDiplomaLogic.cs", "_l_a_b__3___v4_2_student_diploma_logic_8cs.html", "_l_a_b__3___v4_2_student_diploma_logic_8cs" ],
    [ "Teacher.cs", "_l_a_b__3___v4_2_teacher_8cs.html", "_l_a_b__3___v4_2_teacher_8cs" ]
];