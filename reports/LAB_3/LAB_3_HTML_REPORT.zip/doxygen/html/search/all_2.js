var searchData=
[
  ['binarysearchpaper_0',['BinarySearchPaper',['../classlab3agapov__v1_1_1_scientific_paper.html#a66c056b379b5beca556419c8e90b5696',1,'lab3agapov_v1::ScientificPaper']]],
  ['buildreport_1',['BuildReport',['../classlab3agapov__v1_1_1_teacher.html#a9ab496b45f974bb457d2f061a3898bff',1,'lab3agapov_v1::Teacher']]]
];
