var searchData=
[
  ['workwithdiplomaproject_0',['WorkWithDiplomaProject',['../classlab3agapov__v1_1_1_teacher.html#a53359cac3be6d8b4eeece1a706fb20fd',1,'lab3agapov_v1::Teacher']]],
  ['writegradetojournal_1',['WriteGradeToJournal',['../classlab3agapov__v1_1_1_teacher.html#a3029e5eb515435e90796ce10ceaf04dd',1,'lab3agapov_v1::Teacher']]],
  ['writetofile_2',['WriteToFile',['../classlab3agapov__v1_1_1_service.html#a7236f85a149a1f23c40fae049e07cb6e',1,'lab3agapov_v1::Service']]]
];
