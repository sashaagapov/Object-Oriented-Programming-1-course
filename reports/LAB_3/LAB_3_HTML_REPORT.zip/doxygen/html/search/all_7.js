var searchData=
[
  ['givematerial_0',['GiveMaterial',['../classlab3agapov__v1_1_1_teacher.html#a6086a7cd64148d06540c120f072deca0',1,'lab3agapov_v1::Teacher']]],
  ['givematerialtostudentfrominput_1',['GiveMaterialToStudentFromInput',['../classlab3agapov__v1_1_1_teacher.html#a5a6f731a4dfe7262397fb56e36f0f4c8',1,'lab3agapov_v1::Teacher']]],
  ['grade_2',['Grade',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a014a74c12dec78c7dc5a13f4d6b1db69',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['grade_3',['grade',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a88bef95cbb7556f7fed072e95423b6a9',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['gradesjournal_4',['GradesJournal',['../classlab3agapov__v1_1_1_teacher.html#afe4198ac605155451881259d3b7a4122',1,'lab3agapov_v1::Teacher']]],
  ['gradesjournal_5',['gradesJournal',['../classlab3agapov__v1_1_1_teacher.html#a036e8b1128b11533e811e2ec23038ae0',1,'lab3agapov_v1::Teacher']]],
  ['gradeslist_6',['GradesList',['../classlab3agapov__v1_1_1_student.html#a9c1fc7fc65506c0c39987d9ea5026034',1,'lab3agapov_v1::Student']]],
  ['gradeslist_7',['gradesList',['../classlab3agapov__v1_1_1_student.html#ab1fea05d9143a96bfcfab991557d7130',1,'lab3agapov_v1::Student']]],
  ['gradestudent_8',['GradeStudent',['../classlab3agapov__v1_1_1_teacher.html#a90b5c7c6f5b69a0137d3e0a876db09ec',1,'lab3agapov_v1::Teacher']]],
  ['gradestudentfrominput_9',['GradeStudentFromInput',['../classlab3agapov__v1_1_1_teacher.html#a85387e9e44457db58a7b11f6a912b7ef',1,'lab3agapov_v1::Teacher']]]
];
