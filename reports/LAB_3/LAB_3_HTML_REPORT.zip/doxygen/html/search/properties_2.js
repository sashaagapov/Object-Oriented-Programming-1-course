var searchData=
[
  ['grade_0',['Grade',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a014a74c12dec78c7dc5a13f4d6b1db69',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['gradesjournal_1',['GradesJournal',['../classlab3agapov__v1_1_1_teacher.html#afe4198ac605155451881259d3b7a4122',1,'lab3agapov_v1::Teacher']]],
  ['gradeslist_2',['GradesList',['../classlab3agapov__v1_1_1_student.html#a9c1fc7fc65506c0c39987d9ea5026034',1,'lab3agapov_v1::Student']]]
];
