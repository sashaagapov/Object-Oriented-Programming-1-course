var searchData=
[
  ['quantityofstudents_0',['quantityOfStudents',['../classlab3agapov__v1_1_1_teacher.html#a6611bef837f43aa26b08765ee864cb91',1,'lab3agapov_v1::Teacher']]]
];
