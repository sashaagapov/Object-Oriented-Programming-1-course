var searchData=
[
  ['grade_0',['grade',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a88bef95cbb7556f7fed072e95423b6a9',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['gradesjournal_1',['gradesJournal',['../classlab3agapov__v1_1_1_teacher.html#a036e8b1128b11533e811e2ec23038ae0',1,'lab3agapov_v1::Teacher']]],
  ['gradeslist_2',['gradesList',['../classlab3agapov__v1_1_1_student.html#ab1fea05d9143a96bfcfab991557d7130',1,'lab3agapov_v1::Student']]]
];
