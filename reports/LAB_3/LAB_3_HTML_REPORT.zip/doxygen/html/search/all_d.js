var searchData=
[
  ['quantityofstudents_0',['QuantityOfStudents',['../classlab3agapov__v1_1_1_teacher.html#af48ad3601f3f89a0b7c5c8dd43ae1d08',1,'lab3agapov_v1::Teacher']]],
  ['quantityofstudents_1',['quantityOfStudents',['../classlab3agapov__v1_1_1_teacher.html#a6611bef837f43aa26b08765ee864cb91',1,'lab3agapov_v1::Teacher']]]
];
