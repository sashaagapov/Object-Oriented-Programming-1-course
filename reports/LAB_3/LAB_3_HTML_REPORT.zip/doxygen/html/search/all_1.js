var searchData=
[
  ['addgrade_0',['AddGrade',['../classlab3agapov__v1_1_1_student.html#ac4efa450c1aec0611918685801167de9',1,'lab3agapov_v1::Student']]]
];
