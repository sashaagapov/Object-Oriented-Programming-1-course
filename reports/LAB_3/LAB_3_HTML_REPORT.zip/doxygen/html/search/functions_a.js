var searchData=
[
  ['savedata_0',['SaveData',['../classlab3agapov__v1_1_1_teacher.html#a258aac16e3172a788c355f58b375edae',1,'lab3agapov_v1::Teacher']]],
  ['searchscientificpaper_1',['SearchScientificPaper',['../classlab3agapov__v1_1_1_teacher.html#a4b360465530ff6121f854151f1e1bedb',1,'lab3agapov_v1::Teacher']]],
  ['service_2',['Service',['../classlab3agapov__v1_1_1_service.html#a221638bb321abb2ed1a509e4f250770f',1,'lab3agapov_v1.Service.Service()'],['../classlab3agapov__v1_1_1_service.html#ab07bdfd459d456e9c0469cb2cb1ae458',1,'lab3agapov_v1.Service.Service(string outputFormat, string filePath, string dataToProcess)'],['../classlab3agapov__v1_1_1_service.html#a5ecf6902ed64bfc3b5a8d508efcc1f7a',1,'lab3agapov_v1.Service.Service(Service other)']]],
  ['showinformation_3',['ShowInformation',['../classlab3agapov__v1_1_1_teacher.html#a74ba0e249bf5edd283dc872531d7ec15',1,'lab3agapov_v1::Teacher']]],
  ['student_4',['Student',['../classlab3agapov__v1_1_1_student.html#a1c518d79fb081fb8ee0ec15b7572762c',1,'lab3agapov_v1.Student.Student()'],['../classlab3agapov__v1_1_1_student.html#a5f1d757e3dae091040cf50eb1a605c4a',1,'lab3agapov_v1.Student.Student(string studentName, string subjectName, List&lt; int &gt; gradesList, int tasksDone, string downloadedMaterial, double rating, DiplomaProject diploma)'],['../classlab3agapov__v1_1_1_student.html#aae6670dea8cee4d7d9b184f469602716',1,'lab3agapov_v1.Student.Student(Student other)']]]
];
