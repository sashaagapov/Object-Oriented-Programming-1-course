var searchData=
[
  ['teacher_0',['Teacher',['../classlab3agapov__v1_1_1_teacher.html',1,'lab3agapov_v1']]]
];
