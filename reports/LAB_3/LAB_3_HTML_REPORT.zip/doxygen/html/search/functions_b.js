var searchData=
[
  ['teacher_0',['Teacher',['../classlab3agapov__v1_1_1_teacher.html#acd47f6dfaf294ec13ceb667f33afcc3a',1,'lab3agapov_v1.Teacher.Teacher()'],['../classlab3agapov__v1_1_1_teacher.html#a07ee01b89f9982e3c3968147fa32ae40',1,'lab3agapov_v1.Teacher.Teacher(string teacherName, string subjectName, int studyHours, int quantityOfStudents, string gradesJournal, string studyMaterial)'],['../classlab3agapov__v1_1_1_teacher.html#a0ab62597857f7df9a3f722a993618194',1,'lab3agapov_v1.Teacher.Teacher(Teacher other)']]]
];
