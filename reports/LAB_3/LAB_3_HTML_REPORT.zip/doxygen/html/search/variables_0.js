var searchData=
[
  ['datatoprocess_0',['dataToProcess',['../classlab3agapov__v1_1_1_service.html#a89ac054351c16da691b47ec7228d03e5',1,'lab3agapov_v1::Service']]],
  ['diploma_1',['diploma',['../classlab3agapov__v1_1_1_student.html#aa7f0a068a6fb78a03ab426b782b78d53',1,'lab3agapov_v1::Student']]],
  ['downloadedmaterial_2',['downloadedMaterial',['../classlab3agapov__v1_1_1_student.html#a4bc30450d6061ae85d745194aa574efe',1,'lab3agapov_v1::Student']]]
];
