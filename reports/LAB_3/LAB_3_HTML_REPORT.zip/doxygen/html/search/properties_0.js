var searchData=
[
  ['datatoprocess_0',['DataToProcess',['../classlab3agapov__v1_1_1_service.html#a0b82ffa7944c42d89cc26fc6cc754678',1,'lab3agapov_v1::Service']]],
  ['diploma_1',['Diploma',['../classlab3agapov__v1_1_1_student.html#a44df4cd728c0a62d889ff128f6115714',1,'lab3agapov_v1::Student']]],
  ['downloadedmaterial_2',['DownloadedMaterial',['../classlab3agapov__v1_1_1_student.html#a79f5b44a7b01a980e80a5e2bfbe938af',1,'lab3agapov_v1::Student']]]
];
