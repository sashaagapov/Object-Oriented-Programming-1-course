var searchData=
[
  ['decreasestudents_0',['DecreaseStudents',['../classlab3agapov__v1_1_1_teacher.html#ac1c8909ee642b1cdfe96ab3ec99e1aaf',1,'lab3agapov_v1::Teacher']]],
  ['determinecomplexity_1',['DetermineComplexity',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#ab0befeb0bb057fb39a71c4b568429d6c',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['determinegrade_2',['DetermineGrade',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8cbea4ecfab604935a48c09d85f64ce3',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['diplomaproject_3',['DiplomaProject',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a64a6e3fe987ba27ae841d3bdededdfac',1,'lab3agapov_v1.Student.DiplomaProject.DiplomaProject()'],['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a41329f84251f7e027a4053306c214593',1,'lab3agapov_v1.Student.DiplomaProject.DiplomaProject(string themeName, int methodsCount, int themeComplexity, int grade, string supervisorName)'],['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#abf7fbb0ad558715a08acf589ae132982',1,'lab3agapov_v1.Student.DiplomaProject.DiplomaProject(DiplomaProject other)']]],
  ['downloadmaterial_4',['DownloadMaterial',['../classlab3agapov__v1_1_1_student.html#a9c644c6ddc83624845660e6de75eb99b',1,'lab3agapov_v1::Student']]]
];
