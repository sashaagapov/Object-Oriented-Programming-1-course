var searchData=
[
  ['increasestudents_0',['IncreaseStudents',['../classlab3agapov__v1_1_1_teacher.html#ad30e82e061e2ec2267c68b28dd81abf4',1,'lab3agapov_v1::Teacher']]]
];
