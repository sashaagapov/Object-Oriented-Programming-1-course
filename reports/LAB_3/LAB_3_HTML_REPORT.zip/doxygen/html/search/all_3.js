var searchData=
[
  ['calculaterating_0',['CalculateRating',['../classlab3agapov__v1_1_1_student.html#ab25cc2c6c00dfac90d8206975c53dfc8',1,'lab3agapov_v1::Student']]],
  ['changestudyhours_1',['ChangeStudyHours',['../classlab3agapov__v1_1_1_teacher.html#ae19a1a531e785572d799f260d8bf05f9',1,'lab3agapov_v1::Teacher']]],
  ['changeteacherhoursfrominput_2',['ChangeTeacherHoursFromInput',['../classlab3agapov__v1_1_1_teacher.html#a4bdd0123eddd24baceac935971b07957',1,'lab3agapov_v1::Teacher']]],
  ['choosetheme_3',['ChooseTheme',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8150d8709e4ad905cc320a6e3959ff4d',1,'lab3agapov_v1::Student::DiplomaProject']]]
];
