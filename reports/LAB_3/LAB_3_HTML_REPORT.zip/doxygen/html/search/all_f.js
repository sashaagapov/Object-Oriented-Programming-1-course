var searchData=
[
  ['savedata_0',['SaveData',['../classlab3agapov__v1_1_1_teacher.html#a258aac16e3172a788c355f58b375edae',1,'lab3agapov_v1::Teacher']]],
  ['scientificpaper_1',['ScientificPaper',['../classlab3agapov__v1_1_1_scientific_paper.html',1,'lab3agapov_v1']]],
  ['scientificpaper_2ecs_2',['ScientificPaper.cs',['../_scientific_paper_8cs.html',1,'']]],
  ['searchscientificpaper_3',['SearchScientificPaper',['../classlab3agapov__v1_1_1_teacher.html#a4b360465530ff6121f854151f1e1bedb',1,'lab3agapov_v1::Teacher']]],
  ['service_4',['Service',['../classlab3agapov__v1_1_1_service.html',1,'lab3agapov_v1.Service'],['../classlab3agapov__v1_1_1_service.html#a221638bb321abb2ed1a509e4f250770f',1,'lab3agapov_v1.Service.Service()'],['../classlab3agapov__v1_1_1_service.html#ab07bdfd459d456e9c0469cb2cb1ae458',1,'lab3agapov_v1.Service.Service(string outputFormat, string filePath, string dataToProcess)'],['../classlab3agapov__v1_1_1_service.html#a5ecf6902ed64bfc3b5a8d508efcc1f7a',1,'lab3agapov_v1.Service.Service(Service other)']]],
  ['service_2ecs_5',['Service.cs',['../_service_8cs.html',1,'']]],
  ['showinformation_6',['ShowInformation',['../classlab3agapov__v1_1_1_teacher.html#a74ba0e249bf5edd283dc872531d7ec15',1,'lab3agapov_v1::Teacher']]],
  ['student_7',['Student',['../classlab3agapov__v1_1_1_student.html',1,'lab3agapov_v1.Student'],['../classlab3agapov__v1_1_1_student.html#a1c518d79fb081fb8ee0ec15b7572762c',1,'lab3agapov_v1.Student.Student()'],['../classlab3agapov__v1_1_1_student.html#a5f1d757e3dae091040cf50eb1a605c4a',1,'lab3agapov_v1.Student.Student(string studentName, string subjectName, List&lt; int &gt; gradesList, int tasksDone, string downloadedMaterial, double rating, DiplomaProject diploma)'],['../classlab3agapov__v1_1_1_student.html#aae6670dea8cee4d7d9b184f469602716',1,'lab3agapov_v1.Student.Student(Student other)']]],
  ['student_2ecs_8',['Student.cs',['../_student_8cs.html',1,'']]],
  ['studentdiplomalogic_2ecs_9',['StudentDiplomaLogic.cs',['../_student_diploma_logic_8cs.html',1,'']]],
  ['studentname_10',['StudentName',['../classlab3agapov__v1_1_1_student.html#a2231a9efde2f00bd4123fbbff74dcc8d',1,'lab3agapov_v1::Student']]],
  ['studentname_11',['studentName',['../classlab3agapov__v1_1_1_student.html#a15f959c3e281269f02b0b49cf15604f8',1,'lab3agapov_v1::Student']]],
  ['studyhours_12',['StudyHours',['../classlab3agapov__v1_1_1_teacher.html#a8989507e5d87c007ee3e0659618d48d8',1,'lab3agapov_v1::Teacher']]],
  ['studyhours_13',['studyHours',['../classlab3agapov__v1_1_1_teacher.html#aec425b557013c717224b0fa3f4f00577',1,'lab3agapov_v1::Teacher']]],
  ['studymaterial_14',['StudyMaterial',['../classlab3agapov__v1_1_1_teacher.html#a34cfbd5056d483a401946e7893d41055',1,'lab3agapov_v1::Teacher']]],
  ['studymaterial_15',['studyMaterial',['../classlab3agapov__v1_1_1_teacher.html#a122b142ef2ee5f137361029f7bd8cd9d',1,'lab3agapov_v1::Teacher']]],
  ['subjectname_16',['SubjectName',['../classlab3agapov__v1_1_1_student.html#a301f1cb962933e63e5696bec505f66ae',1,'lab3agapov_v1.Student.SubjectName'],['../classlab3agapov__v1_1_1_teacher.html#a6a008c6fbb443d9535a041b4da4f859b',1,'lab3agapov_v1.Teacher.SubjectName']]],
  ['subjectname_17',['subjectName',['../classlab3agapov__v1_1_1_student.html#ac37cf3584894d821257e634bc200f2c1',1,'lab3agapov_v1.Student.subjectName'],['../classlab3agapov__v1_1_1_teacher.html#a7c383417708abda3069005e048e38a0d',1,'lab3agapov_v1.Teacher.subjectName']]],
  ['supervisorname_18',['SupervisorName',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8807438a7e831dc488fdf3e379f2b3f2',1,'lab3agapov_v1::Student::DiplomaProject']]],
  ['supervisorname_19',['supervisorName',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#acf2ce39ac78c0dd47e51cef7aa9c87a4',1,'lab3agapov_v1::Student::DiplomaProject']]]
];
