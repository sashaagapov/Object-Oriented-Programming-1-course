var searchData=
[
  ['viewgrades_0',['ViewGrades',['../classlab3agapov__v1_1_1_student.html#a3c0bf933c2a980bb841b56713fbf27a4',1,'lab3agapov_v1::Student']]]
];
