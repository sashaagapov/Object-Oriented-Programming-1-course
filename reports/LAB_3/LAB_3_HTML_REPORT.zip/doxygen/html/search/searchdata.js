var indexSectionsWithContent =
{
  0: ".abcdefgilmopqrstvw",
  1: "dmpst",
  2: "l",
  3: ".lmpst",
  4: "abcdegimprstvw",
  5: "dfgmoqrst",
  6: "dfgmoqrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "Всі",
  1: "Класи",
  2: "Простори імен",
  3: "Файли",
  4: "Функції",
  5: "Змінні",
  6: "Властивості"
};

