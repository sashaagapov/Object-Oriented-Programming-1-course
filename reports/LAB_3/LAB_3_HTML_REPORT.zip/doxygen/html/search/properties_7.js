var searchData=
[
  ['studentname_0',['StudentName',['../classlab3agapov__v1_1_1_student.html#a2231a9efde2f00bd4123fbbff74dcc8d',1,'lab3agapov_v1::Student']]],
  ['studyhours_1',['StudyHours',['../classlab3agapov__v1_1_1_teacher.html#a8989507e5d87c007ee3e0659618d48d8',1,'lab3agapov_v1::Teacher']]],
  ['studymaterial_2',['StudyMaterial',['../classlab3agapov__v1_1_1_teacher.html#a34cfbd5056d483a401946e7893d41055',1,'lab3agapov_v1::Teacher']]],
  ['subjectname_3',['SubjectName',['../classlab3agapov__v1_1_1_student.html#a301f1cb962933e63e5696bec505f66ae',1,'lab3agapov_v1.Student.SubjectName'],['../classlab3agapov__v1_1_1_teacher.html#a6a008c6fbb443d9535a041b4da4f859b',1,'lab3agapov_v1.Teacher.SubjectName']]],
  ['supervisorname_4',['SupervisorName',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#a8807438a7e831dc488fdf3e379f2b3f2',1,'lab3agapov_v1::Student::DiplomaProject']]]
];
