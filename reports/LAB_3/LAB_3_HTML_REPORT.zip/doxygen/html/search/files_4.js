var searchData=
[
  ['scientificpaper_2ecs_0',['ScientificPaper.cs',['../_scientific_paper_8cs.html',1,'']]],
  ['service_2ecs_1',['Service.cs',['../_service_8cs.html',1,'']]],
  ['student_2ecs_2',['Student.cs',['../_student_8cs.html',1,'']]],
  ['studentdiplomalogic_2ecs_3',['StudentDiplomaLogic.cs',['../_student_diploma_logic_8cs.html',1,'']]]
];
