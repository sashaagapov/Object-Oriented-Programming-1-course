var searchData=
[
  ['givematerial_0',['GiveMaterial',['../classlab3agapov__v1_1_1_teacher.html#a6086a7cd64148d06540c120f072deca0',1,'lab3agapov_v1::Teacher']]],
  ['givematerialtostudentfrominput_1',['GiveMaterialToStudentFromInput',['../classlab3agapov__v1_1_1_teacher.html#a5a6f731a4dfe7262397fb56e36f0f4c8',1,'lab3agapov_v1::Teacher']]],
  ['gradestudent_2',['GradeStudent',['../classlab3agapov__v1_1_1_teacher.html#a90b5c7c6f5b69a0137d3e0a876db09ec',1,'lab3agapov_v1::Teacher']]],
  ['gradestudentfrominput_3',['GradeStudentFromInput',['../classlab3agapov__v1_1_1_teacher.html#a85387e9e44457db58a7b11f6a912b7ef',1,'lab3agapov_v1::Teacher']]]
];
