var searchData=
[
  ['studentname_0',['studentName',['../classlab3agapov__v1_1_1_student.html#a15f959c3e281269f02b0b49cf15604f8',1,'lab3agapov_v1::Student']]],
  ['studyhours_1',['studyHours',['../classlab3agapov__v1_1_1_teacher.html#aec425b557013c717224b0fa3f4f00577',1,'lab3agapov_v1::Teacher']]],
  ['studymaterial_2',['studyMaterial',['../classlab3agapov__v1_1_1_teacher.html#a122b142ef2ee5f137361029f7bd8cd9d',1,'lab3agapov_v1::Teacher']]],
  ['subjectname_3',['subjectName',['../classlab3agapov__v1_1_1_student.html#ac37cf3584894d821257e634bc200f2c1',1,'lab3agapov_v1.Student.subjectName'],['../classlab3agapov__v1_1_1_teacher.html#a7c383417708abda3069005e048e38a0d',1,'lab3agapov_v1.Teacher.subjectName']]],
  ['supervisorname_4',['supervisorName',['../classlab3agapov__v1_1_1_student_1_1_diploma_project.html#acf2ce39ac78c0dd47e51cef7aa9c87a4',1,'lab3agapov_v1::Student::DiplomaProject']]]
];
