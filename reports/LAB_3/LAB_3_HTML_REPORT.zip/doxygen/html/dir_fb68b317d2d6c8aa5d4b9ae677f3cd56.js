var dir_fb68b317d2d6c8aa5d4b9ae677f3cd56 =
[
    [ "Menu.cs", "_l_a_b__3___v3_2_menu_8cs.html", "_l_a_b__3___v3_2_menu_8cs" ],
    [ "Program.cs", "_l_a_b__3___v3_2_program_8cs.html", "_l_a_b__3___v3_2_program_8cs" ],
    [ "Service.cs", "_l_a_b__3___v3_2_service_8cs.html", "_l_a_b__3___v3_2_service_8cs" ],
    [ "Student.cs", "_l_a_b__3___v3_2_student_8cs.html", "_l_a_b__3___v3_2_student_8cs" ],
    [ "StudentDiplomaLogic.cs", "_l_a_b__3___v3_2_student_diploma_logic_8cs.html", "_l_a_b__3___v3_2_student_diploma_logic_8cs" ],
    [ "Teacher.cs", "_l_a_b__3___v3_2_teacher_8cs.html", "_l_a_b__3___v3_2_teacher_8cs" ]
];