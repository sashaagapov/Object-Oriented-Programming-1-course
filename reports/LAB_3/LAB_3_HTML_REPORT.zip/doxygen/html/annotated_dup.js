var annotated_dup =
[
    [ "lab3agapov_v1", "namespacelab3agapov__v1.html", [
      [ "Menu", "classlab3agapov__v1_1_1_menu.html", "classlab3agapov__v1_1_1_menu" ],
      [ "Program", "classlab3agapov__v1_1_1_program.html", "classlab3agapov__v1_1_1_program" ],
      [ "ScientificPaper", "classlab3agapov__v1_1_1_scientific_paper.html", "classlab3agapov__v1_1_1_scientific_paper" ],
      [ "Service", "classlab3agapov__v1_1_1_service.html", "classlab3agapov__v1_1_1_service" ],
      [ "Student", "classlab3agapov__v1_1_1_student.html", "classlab3agapov__v1_1_1_student" ],
      [ "Teacher", "classlab3agapov__v1_1_1_teacher.html", "classlab3agapov__v1_1_1_teacher" ]
    ] ]
];