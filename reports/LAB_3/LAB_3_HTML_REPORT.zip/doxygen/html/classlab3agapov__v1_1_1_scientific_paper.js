var classlab3agapov__v1_1_1_scientific_paper =
[
    [ "BinarySearchPaper", "classlab3agapov__v1_1_1_scientific_paper.html#a66c056b379b5beca556419c8e90b5696", null ]
];