var _scientific_paper_8cs =
[
    [ "lab3agapov_v1.ScientificPaper", "classlab3agapov__v1_1_1_scientific_paper.html", "classlab3agapov__v1_1_1_scientific_paper" ]
];