var dir_96b8d2ba1ff98adb64064b725e691eb1 =
[
    [ "Menu.cs", "_l_a_b__3___v1_2_menu_8cs.html", "_l_a_b__3___v1_2_menu_8cs" ],
    [ "Program.cs", "_l_a_b__3___v1_2_program_8cs.html", "_l_a_b__3___v1_2_program_8cs" ],
    [ "Service.cs", "_l_a_b__3___v1_2_service_8cs.html", "_l_a_b__3___v1_2_service_8cs" ],
    [ "Student.cs", "_l_a_b__3___v1_2_student_8cs.html", "_l_a_b__3___v1_2_student_8cs" ],
    [ "Teacher.cs", "_l_a_b__3___v1_2_teacher_8cs.html", "_l_a_b__3___v1_2_teacher_8cs" ]
];