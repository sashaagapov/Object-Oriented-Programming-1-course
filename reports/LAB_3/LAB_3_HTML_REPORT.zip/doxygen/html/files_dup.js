var files_dup =
[
    [ "obj", "dir_43724e81dd40e09f32417973865cdd64.html", "dir_43724e81dd40e09f32417973865cdd64" ],
    [ "Menu.cs", "_menu_8cs.html", "_menu_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "ScientificPaper.cs", "_scientific_paper_8cs.html", "_scientific_paper_8cs" ],
    [ "Service.cs", "_service_8cs.html", "_service_8cs" ],
    [ "Student.cs", "_student_8cs.html", "_student_8cs" ],
    [ "StudentDiplomaLogic.cs", "_student_diploma_logic_8cs.html", "_student_diploma_logic_8cs" ],
    [ "Teacher.cs", "_teacher_8cs.html", "_teacher_8cs" ]
];