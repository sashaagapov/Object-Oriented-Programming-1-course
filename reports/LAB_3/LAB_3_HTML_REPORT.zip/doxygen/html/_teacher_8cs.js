var _teacher_8cs =
[
    [ "lab3agapov_v1.Teacher", "classlab3agapov__v1_1_1_teacher.html", "classlab3agapov__v1_1_1_teacher" ]
];