var classlab3agapov__v1_1_1_menu =
[
    [ "PrintOptions", "classlab3agapov__v1_1_1_menu.html#a7be782c20ac2a4eaf83fc14b9b6b0cbb", null ],
    [ "ReadCommand", "classlab3agapov__v1_1_1_menu.html#a8689c488c8b8b6dc2cb680ee733d1aec", null ]
];