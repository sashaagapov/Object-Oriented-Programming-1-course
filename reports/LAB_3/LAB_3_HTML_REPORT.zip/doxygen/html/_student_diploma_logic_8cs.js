var _student_diploma_logic_8cs =
[
    [ "lab3agapov_v1.Student", "classlab3agapov__v1_1_1_student.html", "classlab3agapov__v1_1_1_student" ],
    [ "lab3agapov_v1.Student.DiplomaProject", "classlab3agapov__v1_1_1_student_1_1_diploma_project.html", "classlab3agapov__v1_1_1_student_1_1_diploma_project" ]
];