var classlab5agapov__v2_1_1_menu =
[
    [ "Menu", "classlab5agapov__v2_1_1_menu.html#a6eaa332cbd6c56a861843c148afcf36f", null ],
    [ "Menu", "classlab5agapov__v2_1_1_menu.html#ad2415302d126b64ff187bc00c1f4cca4", null ],
    [ "Menu", "classlab5agapov__v2_1_1_menu.html#a169f9eaf7db2c79e4eb3ddc9e632bba5", null ],
    [ "ChangeTeacherHours", "classlab5agapov__v2_1_1_menu.html#a995c7898cd9e49cd49bb40608de893f1", null ],
    [ "DecreaseStudents", "classlab5agapov__v2_1_1_menu.html#a0d8b6fb368366c47109161eae019340f", null ],
    [ "GiveMaterialToStudent", "classlab5agapov__v2_1_1_menu.html#af8ef66ba19f6f44e5fa787c8bbcdcc94", null ],
    [ "GradeStudent", "classlab5agapov__v2_1_1_menu.html#affc4575bd7dd2da1c3b4d90c9d635a03", null ],
    [ "IncreaseStudents", "classlab5agapov__v2_1_1_menu.html#a9b1e230f272cd4bd9bd1eb66f5798f8e", null ],
    [ "ReadNotEmptyText", "classlab5agapov__v2_1_1_menu.html#add049f32654b143e5bbb8130ea0dc115", null ],
    [ "ReadNumberInRange", "classlab5agapov__v2_1_1_menu.html#a266d3d1ba17d4e072c51036c5214b211", null ],
    [ "Run", "classlab5agapov__v2_1_1_menu.html#a39ca178ae42e29133f03be25e518dd39", null ],
    [ "SaveData", "classlab5agapov__v2_1_1_menu.html#a0133575b4502277ffdf2ed515f810353", null ],
    [ "ShowInformation", "classlab5agapov__v2_1_1_menu.html#af4d31d3d66bef05aeb64e980b727f67b", null ],
    [ "service", "classlab5agapov__v2_1_1_menu.html#af4859aa5f3d564273fe996bad770c4cd", null ],
    [ "student", "classlab5agapov__v2_1_1_menu.html#a386b59eea0658e5985891d0e8bf30fce", null ],
    [ "teacher", "classlab5agapov__v2_1_1_menu.html#aeae03f30c1557d55fb7889c456dbd945", null ]
];