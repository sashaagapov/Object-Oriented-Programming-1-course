var dir_2aa6d5f429bc0720e28bfd642e7a74bb =
[
    [ "DiplomaProject.cs", "_l_a_b__5___v1_2_diploma_project_8cs.html", "_l_a_b__5___v1_2_diploma_project_8cs" ],
    [ "Menu.cs", "_l_a_b__5___v1_2_menu_8cs.html", "_l_a_b__5___v1_2_menu_8cs" ],
    [ "Person.cs", "_l_a_b__5___v1_2_person_8cs.html", "_l_a_b__5___v1_2_person_8cs" ],
    [ "Program.cs", "_l_a_b__5___v1_2_program_8cs.html", "_l_a_b__5___v1_2_program_8cs" ],
    [ "Service.cs", "_l_a_b__5___v1_2_service_8cs.html", "_l_a_b__5___v1_2_service_8cs" ],
    [ "Student.cs", "_l_a_b__5___v1_2_student_8cs.html", "_l_a_b__5___v1_2_student_8cs" ],
    [ "Teacher.cs", "_l_a_b__5___v1_2_teacher_8cs.html", "_l_a_b__5___v1_2_teacher_8cs" ]
];