var dir_95615df0888b709c73ffaa0c61be4819 =
[
    [ "DiplomaProject.cs", "_l_a_b__5___v3_2_diploma_project_8cs.html", "_l_a_b__5___v3_2_diploma_project_8cs" ],
    [ "Menu.cs", "_l_a_b__5___v3_2_menu_8cs.html", "_l_a_b__5___v3_2_menu_8cs" ],
    [ "Person.cs", "_l_a_b__5___v3_2_person_8cs.html", "_l_a_b__5___v3_2_person_8cs" ],
    [ "Program.cs", "_l_a_b__5___v3_2_program_8cs.html", "_l_a_b__5___v3_2_program_8cs" ],
    [ "Service.cs", "_l_a_b__5___v3_2_service_8cs.html", "_l_a_b__5___v3_2_service_8cs" ],
    [ "Student.cs", "_l_a_b__5___v3_2_student_8cs.html", "_l_a_b__5___v3_2_student_8cs" ],
    [ "StudentGroup.cs", "_student_group_8cs.html", "_student_group_8cs" ],
    [ "Teacher.cs", "_l_a_b__5___v3_2_teacher_8cs.html", "_l_a_b__5___v3_2_teacher_8cs" ]
];