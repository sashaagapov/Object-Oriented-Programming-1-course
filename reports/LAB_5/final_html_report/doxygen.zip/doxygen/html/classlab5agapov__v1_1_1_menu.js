var classlab5agapov__v1_1_1_menu =
[
    [ "Menu", "classlab5agapov__v1_1_1_menu.html#ad037dbf69bbeeddb0d0dbb852b91e7c6", null ],
    [ "Menu", "classlab5agapov__v1_1_1_menu.html#add04929e4489506d1ce314745d529454", null ],
    [ "Menu", "classlab5agapov__v1_1_1_menu.html#a000534ec849c7f3b0e6a0de9e1b78b7b", null ],
    [ "ChangeTeacherHours", "classlab5agapov__v1_1_1_menu.html#a97604e4bdd778966f020caf46b5f46c3", null ],
    [ "DecreaseStudents", "classlab5agapov__v1_1_1_menu.html#aac7a3660103daf781cea38d2ef740e71", null ],
    [ "GiveMaterialToStudent", "classlab5agapov__v1_1_1_menu.html#af0a070c408a55f0c65b8db9dc706f63a", null ],
    [ "GradeStudent", "classlab5agapov__v1_1_1_menu.html#a81ed98704fedbb1b666cdb335b4aba46", null ],
    [ "IncreaseStudents", "classlab5agapov__v1_1_1_menu.html#a5a4c23ba33727fc67fc7a45830d04900", null ],
    [ "ReadNotEmptyText", "classlab5agapov__v1_1_1_menu.html#a625a5d479a854ef3bc967e1420d28c9c", null ],
    [ "ReadNumberInRange", "classlab5agapov__v1_1_1_menu.html#ad8ce5bf37e66221f02f09c05aebf7693", null ],
    [ "Run", "classlab5agapov__v1_1_1_menu.html#a3a8c9183c1e721f1a3a20ca86781729a", null ],
    [ "SaveData", "classlab5agapov__v1_1_1_menu.html#a728b965073409b75a6ac55798b0e9aeb", null ],
    [ "ShowInformation", "classlab5agapov__v1_1_1_menu.html#a8e53586ed5047bcff5702f411019bf9d", null ],
    [ "service", "classlab5agapov__v1_1_1_menu.html#a4e465f8e1eb50e365509e16d2ef2be43", null ],
    [ "student", "classlab5agapov__v1_1_1_menu.html#aa3113dbcec394d42d4f0311b55767336", null ],
    [ "teacher", "classlab5agapov__v1_1_1_menu.html#af30b11fb2d2703bdda8d7c2cd6b7d925", null ]
];