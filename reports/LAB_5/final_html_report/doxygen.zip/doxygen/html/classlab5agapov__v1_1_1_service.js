var classlab5agapov__v1_1_1_service =
[
    [ "Service", "classlab5agapov__v1_1_1_service.html#a884d6bc65c181fd86ba0ab418091f906", null ],
    [ "Service", "classlab5agapov__v1_1_1_service.html#aaa7ef18be84ab1af3a96fa28766d7463", null ],
    [ "Service", "classlab5agapov__v1_1_1_service.html#a0772d14ba9f3e603ce180295d31f9100", null ],
    [ "PrintAndSave", "classlab5agapov__v1_1_1_service.html#aaa85696f42332a9cd49d8bf3b1ffd901", null ],
    [ "PrintToConsole", "classlab5agapov__v1_1_1_service.html#aa7b89c8c470cf8e70136d634a4519f73", null ],
    [ "ReadFromConsole", "classlab5agapov__v1_1_1_service.html#a87ee09a70f30b37a9316b2718e4bb386", null ],
    [ "ReadFromFile", "classlab5agapov__v1_1_1_service.html#ada5f4f950902bd45d2145275e6f95c80", null ],
    [ "SaveProtocolToFile", "classlab5agapov__v1_1_1_service.html#a7fdc37003228d0ef877b61d4a8e4d08b", null ],
    [ "SaveReport", "classlab5agapov__v1_1_1_service.html#a73040ed47c3ec163a3d28d14abdf450b", null ],
    [ "dataToProcess", "classlab5agapov__v1_1_1_service.html#a8127caf59328f74bd0d034c6edc4a59d", null ],
    [ "filePath", "classlab5agapov__v1_1_1_service.html#a79ad2ba47615afe7fd265a1d7871e65c", null ],
    [ "outputFormat", "classlab5agapov__v1_1_1_service.html#a13afb47d95f8ef713c948484d1030e87", null ],
    [ "protocol", "classlab5agapov__v1_1_1_service.html#ac4c9b6686800367e66ecfb63cb107390", null ],
    [ "DataToProcess", "classlab5agapov__v1_1_1_service.html#aaf5a0ec5408372befe394db9762850b7", null ],
    [ "FilePath", "classlab5agapov__v1_1_1_service.html#a839ee8d2ab8c25c8dad19e2c65341a3c", null ],
    [ "OutputFormat", "classlab5agapov__v1_1_1_service.html#a7c2714a726e4215ad89455421d8903f8", null ]
];