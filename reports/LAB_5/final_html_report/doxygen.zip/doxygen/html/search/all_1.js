var searchData=
[
  ['addgrade_0',['AddGrade',['../classlab5agapov__v3_1_1_student.html#ab5584f11d216ef0d87af31f9f20cea35',1,'lab5agapov_v3::Student']]],
  ['addstudent_1',['AddStudent',['../classlab5agapov__v3_1_1_student_group.html#adb1d155997ca63c5189e41beccb36a85',1,'lab5agapov_v3::StudentGroup']]],
  ['algorithmscount_2',['AlgorithmsCount',['../classlab5agapov__v3_1_1_diploma_project.html#adb4ed3baeb09e67963ee207cdec5f5fa',1,'lab5agapov_v3::DiplomaProject']]],
  ['appendprotocol_3',['AppendProtocol',['../classlab5agapov__v3_1_1_service.html#aca84185c3651588104303d39cc314802',1,'lab5agapov_v3::Service']]]
];
