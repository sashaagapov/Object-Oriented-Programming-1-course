var searchData=
[
  ['tasksdone_0',['tasksDone',['../classlab5agapov__v3_1_1_student.html#a2f8e0408eaa8c10e80d67bf982a9b958',1,'lab5agapov_v3::Student']]]
];
