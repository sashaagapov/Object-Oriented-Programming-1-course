var searchData=
[
  ['name_0',['name',['../classlab5agapov__v3_1_1_person.html#a73564d60d05cd5436923e11e57d1ae35',1,'lab5agapov_v3::Person']]]
];
