var searchData=
[
  ['teacher_0',['Teacher',['../classlab5agapov__v3_1_1_teacher.html',1,'lab5agapov_v3']]]
];
