var searchData=
[
  ['quantityofstudents_0',['QuantityOfStudents',['../classlab5agapov__v3_1_1_teacher.html#a3241af35e00c8058b5f24a30945efc47',1,'lab5agapov_v3::Teacher']]],
  ['quantityofstudents_1',['quantityOfStudents',['../classlab5agapov__v3_1_1_teacher.html#aab711ce2ba9c1347536cf24302d9877b',1,'lab5agapov_v3::Teacher']]]
];
