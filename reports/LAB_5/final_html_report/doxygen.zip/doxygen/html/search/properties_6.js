var searchData=
[
  ['name_0',['Name',['../classlab5agapov__v3_1_1_person.html#af6b895916993e3e35bb82a7d630d87c2',1,'lab5agapov_v3::Person']]]
];
