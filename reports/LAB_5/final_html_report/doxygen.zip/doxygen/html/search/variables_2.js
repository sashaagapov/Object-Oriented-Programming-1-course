var searchData=
[
  ['gradesjournal_0',['gradesJournal',['../classlab5agapov__v3_1_1_teacher.html#afa0b14b13c3601d6012bd4d8d25f75b9',1,'lab5agapov_v3::Teacher']]],
  ['gradeslist_1',['gradesList',['../classlab5agapov__v3_1_1_student.html#abc397a4fec5094f022926c3151ab80e3',1,'lab5agapov_v3::Student']]]
];
