var searchData=
[
  ['datatoprocess_0',['dataToProcess',['../classlab5agapov__v3_1_1_service.html#a33b0a454eda85894024dab2a5890790a',1,'lab5agapov_v3::Service']]],
  ['downloadedmaterial_1',['downloadedMaterial',['../classlab5agapov__v3_1_1_student.html#ab1128cdd7a0119961e0836b08eab51ad',1,'lab5agapov_v3::Student']]]
];
