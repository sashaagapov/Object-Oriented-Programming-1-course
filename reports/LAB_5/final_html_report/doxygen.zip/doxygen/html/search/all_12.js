var searchData=
[
  ['viewgrades_0',['ViewGrades',['../classlab5agapov__v3_1_1_student.html#a1b46410d419589807db367975b40da42',1,'lab5agapov_v3::Student']]]
];
