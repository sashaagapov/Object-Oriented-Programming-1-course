var indexSectionsWithContent =
{
  0: ".abcdefgilmnopqrstvw",
  1: "dmpst",
  2: "l",
  3: ".dlmpst",
  4: "abcdegimoprstvw",
  5: "dfgnopqrst",
  6: "acdfgmnoqrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "Всі",
  1: "Класи",
  2: "Простори імен",
  3: "Файли",
  4: "Функції",
  5: "Змінні",
  6: "Властивості"
};

