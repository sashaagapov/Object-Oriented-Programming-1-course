var searchData=
[
  ['equals_0',['Equals',['../classlab5agapov__v3_1_1_diploma_project.html#a9887b8c9a8289ed801d85353395edb08',1,'lab5agapov_v3.DiplomaProject.Equals()'],['../classlab5agapov__v3_1_1_student.html#a8e8ad20aba3ba6cf48e66f5fd5a3bf66',1,'lab5agapov_v3.Student.Equals()'],['../classlab5agapov__v3_1_1_teacher.html#a8a8c663f52a52053eaa3d02fe3790187',1,'lab5agapov_v3.Teacher.Equals()']]]
];
