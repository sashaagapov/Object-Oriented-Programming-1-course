var searchData=
[
  ['teacher_0',['Teacher',['../classlab5agapov__v3_1_1_teacher.html#a0fc8210bfadebcbc40b555c1e57f37f5',1,'lab5agapov_v3.Teacher.Teacher()'],['../classlab5agapov__v3_1_1_teacher.html#a9e34959c83078029e3a56f2a49fa2b81',1,'lab5agapov_v3.Teacher.Teacher(string teacherName, string subjectName, int studyHours, int quantityOfStudents, string gradesJournal, string studyMaterial)'],['../classlab5agapov__v3_1_1_teacher.html#a23ccefc90273a0ab5bad033c8b95e6f9',1,'lab5agapov_v3.Teacher.Teacher(Teacher other)']]]
];
