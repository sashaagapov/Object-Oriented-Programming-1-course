var searchData=
[
  ['datatoprocess_0',['DataToProcess',['../classlab5agapov__v3_1_1_service.html#aa06c4eb13018adad34af2183a913045e',1,'lab5agapov_v3::Service']]],
  ['difficulty_1',['Difficulty',['../classlab5agapov__v3_1_1_diploma_project.html#a527107b837b61d3ee7313d03fa554c1c',1,'lab5agapov_v3::DiplomaProject']]],
  ['downloadedmaterial_2',['DownloadedMaterial',['../classlab5agapov__v3_1_1_student.html#a85d9ab9eaab5d0f0542927e23c28c2f1',1,'lab5agapov_v3::Student']]]
];
