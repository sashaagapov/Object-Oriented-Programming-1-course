var searchData=
[
  ['increasestudents_0',['IncreaseStudents',['../classlab5agapov__v3_1_1_teacher.html#aa31a3d5ee759900450a506ad0a92ee6c',1,'lab5agapov_v3::Teacher']]]
];
