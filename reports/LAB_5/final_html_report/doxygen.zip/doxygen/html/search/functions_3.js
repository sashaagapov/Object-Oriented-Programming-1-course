var searchData=
[
  ['decreasestudents_0',['DecreaseStudents',['../classlab5agapov__v3_1_1_teacher.html#ac7b414833cebbc72f693eabffc5f271b',1,'lab5agapov_v3::Teacher']]],
  ['diplomaproject_1',['DiplomaProject',['../classlab5agapov__v3_1_1_diploma_project.html#a8235f06b57d721ebffb4b0b0523bbd16',1,'lab5agapov_v3.DiplomaProject.DiplomaProject()'],['../classlab5agapov__v3_1_1_diploma_project.html#a6adf8f99e0ea2185df5837c5f8b64ff3',1,'lab5agapov_v3.DiplomaProject.DiplomaProject(string themeName, int algorithmsCount, string difficulty, int mark, string supervisorName)'],['../classlab5agapov__v3_1_1_diploma_project.html#a2fa6cd91fb472e823bd85274854de98b',1,'lab5agapov_v3.DiplomaProject.DiplomaProject(DiplomaProject other)']]],
  ['downloadmaterial_2',['DownloadMaterial',['../classlab5agapov__v3_1_1_student.html#ac3f9da78a14fb03b489ece3149325105',1,'lab5agapov_v3::Student']]]
];
