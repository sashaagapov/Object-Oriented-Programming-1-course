var searchData=
[
  ['gradesjournal_0',['GradesJournal',['../classlab5agapov__v3_1_1_teacher.html#a25bcb5f1bf14910f91100236f13cbf36',1,'lab5agapov_v3::Teacher']]],
  ['gradeslist_1',['GradesList',['../classlab5agapov__v3_1_1_student.html#a911dd1228bc9ef060c8950fb36df831f',1,'lab5agapov_v3::Student']]]
];
