var searchData=
[
  ['writegradetojournal_0',['WriteGradeToJournal',['../classlab5agapov__v3_1_1_teacher.html#ab5d623d7bb8b9cc5d97608a4ffe6a805',1,'lab5agapov_v3::Teacher']]],
  ['writetofile_1',['WriteToFile',['../classlab5agapov__v3_1_1_service.html#acd071f9ff7176a26da92b7026d4980ce',1,'lab5agapov_v3::Service']]]
];
