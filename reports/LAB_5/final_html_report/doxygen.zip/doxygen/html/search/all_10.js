var searchData=
[
  ['savedata_0',['SaveData',['../classlab5agapov__v3_1_1_teacher.html#a46902c808aa90f41c90175b2b3edc2f0',1,'lab5agapov_v3::Teacher']]],
  ['saveprotocoltofile_1',['SaveProtocolToFile',['../classlab5agapov__v3_1_1_service.html#a884c758be40d78f5a3cc271c7ec302fe',1,'lab5agapov_v3::Service']]],
  ['service_2',['Service',['../classlab5agapov__v3_1_1_service.html',1,'lab5agapov_v3.Service'],['../classlab5agapov__v3_1_1_service.html#abedcd4bc3f91c7835ec9c8b12f174e83',1,'lab5agapov_v3.Service.Service()'],['../classlab5agapov__v3_1_1_service.html#a1690cd2c8216ad215700426598c7581b',1,'lab5agapov_v3.Service.Service(string outputFormat, string filePath, string dataToProcess)'],['../classlab5agapov__v3_1_1_service.html#a6e40622f0b295fae3a4cb0eb3b6b526c',1,'lab5agapov_v3.Service.Service(Service other)']]],
  ['service_2ecs_3',['Service.cs',['../_service_8cs.html',1,'']]],
  ['showgroupinformation_4',['ShowGroupInformation',['../classlab5agapov__v3_1_1_teacher.html#ae2af38964d3b3e486785e129a01598cc',1,'lab5agapov_v3::Teacher']]],
  ['showinformation_5',['ShowInformation',['../classlab5agapov__v3_1_1_teacher.html#a6e654d4c4ec9cb007d734bfdf4dfb57e',1,'lab5agapov_v3::Teacher']]],
  ['student_6',['Student',['../classlab5agapov__v3_1_1_student.html',1,'lab5agapov_v3.Student'],['../classlab5agapov__v3_1_1_student.html#ad12afc48ac8d53a0a9d736c6f023f670',1,'lab5agapov_v3.Student.Student()'],['../classlab5agapov__v3_1_1_student.html#a4ec736142d4f94faa117a84aec8358fa',1,'lab5agapov_v3.Student.Student(string studentName, string subjectName, List&lt; int &gt; gradesList, int tasksDone, string downloadedMaterial, double rating)'],['../classlab5agapov__v3_1_1_student.html#a3cf924e26be9369f25b7842aaaa4e799',1,'lab5agapov_v3.Student.Student(Student other)']]],
  ['student_2ecs_7',['Student.cs',['../_student_8cs.html',1,'']]],
  ['studentgroup_8',['StudentGroup',['../classlab5agapov__v3_1_1_student_group.html',1,'lab5agapov_v3.StudentGroup'],['../classlab5agapov__v3_1_1_student_group.html#abaf0f0c3cd31206d180e2d0a14ff3f65',1,'lab5agapov_v3.StudentGroup.StudentGroup()']]],
  ['studentgroup_2ecs_9',['StudentGroup.cs',['../_student_group_8cs.html',1,'']]],
  ['studentname_10',['StudentName',['../classlab5agapov__v3_1_1_student.html#ac8e9d8d6ef5e46dbaf5a54374755c235',1,'lab5agapov_v3::Student']]],
  ['students_11',['students',['../classlab5agapov__v3_1_1_student_group.html#a576b5a336aa377d895e83fea6e325b45',1,'lab5agapov_v3::StudentGroup']]],
  ['studyhours_12',['StudyHours',['../classlab5agapov__v3_1_1_teacher.html#a9591fc53cb25a703db1592cff6ebadd7',1,'lab5agapov_v3::Teacher']]],
  ['studyhours_13',['studyHours',['../classlab5agapov__v3_1_1_teacher.html#a9c4b555392fd43bd5ab0cbb8b96866e7',1,'lab5agapov_v3::Teacher']]],
  ['studymaterial_14',['StudyMaterial',['../classlab5agapov__v3_1_1_teacher.html#a005170fbedf5aa328c3e7c0257a22ee4',1,'lab5agapov_v3::Teacher']]],
  ['studymaterial_15',['studyMaterial',['../classlab5agapov__v3_1_1_teacher.html#a29ea27f36231ee3ec5593b776894c12a',1,'lab5agapov_v3::Teacher']]],
  ['subjectname_16',['SubjectName',['../classlab5agapov__v3_1_1_person.html#ad582f3a2a88e7aad031e6cdd435db1b1',1,'lab5agapov_v3::Person']]],
  ['subjectname_17',['subjectName',['../classlab5agapov__v3_1_1_person.html#a6da195daaf9ebcb0ca72eedf91e0169b',1,'lab5agapov_v3::Person']]],
  ['supervisorname_18',['SupervisorName',['../classlab5agapov__v3_1_1_diploma_project.html#aa86b1c1a10efe407b34ad8e0b76ecac2',1,'lab5agapov_v3::DiplomaProject']]]
];
