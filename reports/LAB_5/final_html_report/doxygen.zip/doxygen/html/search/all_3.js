var searchData=
[
  ['calculaterating_0',['CalculateRating',['../classlab5agapov__v3_1_1_student.html#a24e2e7091eab3b183e853e04e63794fc',1,'lab5agapov_v3::Student']]],
  ['changestudyhours_1',['ChangeStudyHours',['../classlab5agapov__v3_1_1_teacher.html#a25005fd7b230a6c2d45b4a6d85df5dd7',1,'lab5agapov_v3::Teacher']]],
  ['changeteacherhoursfrominput_2',['ChangeTeacherHoursFromInput',['../classlab5agapov__v3_1_1_teacher.html#aaf7b77c9e0a967314d844e37d7eb6dbe',1,'lab5agapov_v3::Teacher']]],
  ['count_3',['Count',['../classlab5agapov__v3_1_1_student_group.html#a18806dab268c72e5dcfbfd30e07a7a55',1,'lab5agapov_v3::StudentGroup']]]
];
