var searchData=
[
  ['gethashcode_0',['GetHashCode',['../classlab5agapov__v3_1_1_diploma_project.html#ad4566faab621cebb2a264373b729da26',1,'lab5agapov_v3.DiplomaProject.GetHashCode()'],['../classlab5agapov__v3_1_1_student.html#a68d975c1ac417011be572a24c5a8745b',1,'lab5agapov_v3.Student.GetHashCode()'],['../classlab5agapov__v3_1_1_teacher.html#a2193e8f85f189d13571165a6d45af9ed',1,'lab5agapov_v3.Teacher.GetHashCode()']]],
  ['getinfo_1',['GetInfo',['../classlab5agapov__v3_1_1_diploma_project.html#a7f72554f313ba1fdc74ccc3d870808bb',1,'lab5agapov_v3.DiplomaProject.GetInfo()'],['../classlab5agapov__v3_1_1_person.html#ad10e09d3429e4a21a4b19950d475340d',1,'lab5agapov_v3.Person.GetInfo()'],['../classlab5agapov__v3_1_1_student.html#ad70ebe180123bf3e7403ba3651a84eaf',1,'lab5agapov_v3.Student.GetInfo()'],['../classlab5agapov__v3_1_1_student_group.html#a4ff85ebb696b85b630eb21bf1a0aebea',1,'lab5agapov_v3.StudentGroup.GetInfo()'],['../classlab5agapov__v3_1_1_teacher.html#aacbbd8721d8440e5830b130e1ebd5a00',1,'lab5agapov_v3.Teacher.GetInfo()']]],
  ['givematerial_2',['GiveMaterial',['../classlab5agapov__v3_1_1_teacher.html#ae03e903796350594896b40970e8050c1',1,'lab5agapov_v3::Teacher']]],
  ['givematerialtostudentfrominput_3',['GiveMaterialToStudentFromInput',['../classlab5agapov__v3_1_1_teacher.html#a8ac697051695560cd1756086befe1bd5',1,'lab5agapov_v3::Teacher']]],
  ['gradestudent_4',['GradeStudent',['../classlab5agapov__v3_1_1_teacher.html#a70f42c00807bdd52007661cb5e8f9b0b',1,'lab5agapov_v3::Teacher']]],
  ['gradestudentfrominput_5',['GradeStudentFromInput',['../classlab5agapov__v3_1_1_teacher.html#a3f20fc4d4a8880acca6c9962082526b5',1,'lab5agapov_v3::Teacher']]]
];
