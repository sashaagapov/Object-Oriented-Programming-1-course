var searchData=
[
  ['name_0',['Name',['../classlab5agapov__v3_1_1_person.html#af6b895916993e3e35bb82a7d630d87c2',1,'lab5agapov_v3::Person']]],
  ['name_1',['name',['../classlab5agapov__v3_1_1_person.html#a73564d60d05cd5436923e11e57d1ae35',1,'lab5agapov_v3::Person']]]
];
