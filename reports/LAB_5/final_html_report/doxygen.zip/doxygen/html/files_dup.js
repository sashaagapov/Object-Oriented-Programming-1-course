var files_dup =
[
    [ "obj", "dir_43724e81dd40e09f32417973865cdd64.html", "dir_43724e81dd40e09f32417973865cdd64" ],
    [ "DiplomaProject.cs", "_diploma_project_8cs.html", "_diploma_project_8cs" ],
    [ "Menu.cs", "_menu_8cs.html", "_menu_8cs" ],
    [ "Person.cs", "_person_8cs.html", "_person_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "Service.cs", "_service_8cs.html", "_service_8cs" ],
    [ "Student.cs", "_student_8cs.html", "_student_8cs" ],
    [ "StudentGroup.cs", "_student_group_8cs.html", "_student_group_8cs" ],
    [ "Teacher.cs", "_teacher_8cs.html", "_teacher_8cs" ]
];