var annotated_dup =
[
    [ "lab5agapov_v3", "namespacelab5agapov__v3.html", [
      [ "DiplomaProject", "classlab5agapov__v3_1_1_diploma_project.html", "classlab5agapov__v3_1_1_diploma_project" ],
      [ "Menu", "classlab5agapov__v3_1_1_menu.html", "classlab5agapov__v3_1_1_menu" ],
      [ "Person", "classlab5agapov__v3_1_1_person.html", "classlab5agapov__v3_1_1_person" ],
      [ "Program", "classlab5agapov__v3_1_1_program.html", "classlab5agapov__v3_1_1_program" ],
      [ "Service", "classlab5agapov__v3_1_1_service.html", "classlab5agapov__v3_1_1_service" ],
      [ "Student", "classlab5agapov__v3_1_1_student.html", "classlab5agapov__v3_1_1_student" ],
      [ "StudentGroup", "classlab5agapov__v3_1_1_student_group.html", "classlab5agapov__v3_1_1_student_group" ],
      [ "Teacher", "classlab5agapov__v3_1_1_teacher.html", "classlab5agapov__v3_1_1_teacher" ]
    ] ]
];