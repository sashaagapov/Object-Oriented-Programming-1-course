var dir_7b6fa2819fbd4432b86da07ed6f7d015 =
[
    [ "DiplomaProject.cs", "_l_a_b__5___v2_2_diploma_project_8cs.html", "_l_a_b__5___v2_2_diploma_project_8cs" ],
    [ "Menu.cs", "_l_a_b__5___v2_2_menu_8cs.html", "_l_a_b__5___v2_2_menu_8cs" ],
    [ "Person.cs", "_l_a_b__5___v2_2_person_8cs.html", "_l_a_b__5___v2_2_person_8cs" ],
    [ "Program.cs", "_l_a_b__5___v2_2_program_8cs.html", "_l_a_b__5___v2_2_program_8cs" ],
    [ "Service.cs", "_l_a_b__5___v2_2_service_8cs.html", "_l_a_b__5___v2_2_service_8cs" ],
    [ "Student.cs", "_l_a_b__5___v2_2_student_8cs.html", "_l_a_b__5___v2_2_student_8cs" ],
    [ "Teacher.cs", "_l_a_b__5___v2_2_teacher_8cs.html", "_l_a_b__5___v2_2_teacher_8cs" ]
];