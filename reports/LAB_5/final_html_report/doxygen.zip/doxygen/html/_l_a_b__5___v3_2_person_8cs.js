var _l_a_b__5___v3_2_person_8cs =
[
    [ "lab5agapov_v3.Person", "classlab5agapov__v3_1_1_person.html", "classlab5agapov__v3_1_1_person" ]
];