var classlab5agapov__v2_1_1_program =
[
    [ "Main", "classlab5agapov__v2_1_1_program.html#a8ccdbe238758382ca6a430c686a76752", null ]
];