var classlab5agapov__v1_1_1_person =
[
    [ "Person", "classlab5agapov__v1_1_1_person.html#a1187251156faea7ca584b2367b810650", null ],
    [ "Person", "classlab5agapov__v1_1_1_person.html#a8865817cd05ccc2fdb56061f81a44bef", null ],
    [ "Person", "classlab5agapov__v1_1_1_person.html#a79eda4c1be93d756ee3de29f51303e81", null ],
    [ "GetInfo", "classlab5agapov__v1_1_1_person.html#abf5370d53c932dacf7e045952dd8c1ca", null ],
    [ "name", "classlab5agapov__v1_1_1_person.html#af9ad39c7f7f74589d74926a095a5d20c", null ],
    [ "subjectName", "classlab5agapov__v1_1_1_person.html#a145c001a687aeff589d03e920b9554e4", null ],
    [ "Name", "classlab5agapov__v1_1_1_person.html#a3a0c09533f01d0009e77ed4d4bcad3e3", null ],
    [ "SubjectName", "classlab5agapov__v1_1_1_person.html#ac86c7d00640cb4c1980211d48a9382c4", null ]
];