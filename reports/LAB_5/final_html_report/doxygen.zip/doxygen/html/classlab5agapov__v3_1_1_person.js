var classlab5agapov__v3_1_1_person =
[
    [ "Person", "classlab5agapov__v3_1_1_person.html#af1364950d10bdcf81b0113799c06856a", null ],
    [ "Person", "classlab5agapov__v3_1_1_person.html#a15fd3693a64a531bef66a27f2a78f2d5", null ],
    [ "Person", "classlab5agapov__v3_1_1_person.html#a071070b8224a0a66f7fd57d7d7d0e9e7", null ],
    [ "GetInfo", "classlab5agapov__v3_1_1_person.html#ad10e09d3429e4a21a4b19950d475340d", null ],
    [ "name", "classlab5agapov__v3_1_1_person.html#a73564d60d05cd5436923e11e57d1ae35", null ],
    [ "subjectName", "classlab5agapov__v3_1_1_person.html#a6da195daaf9ebcb0ca72eedf91e0169b", null ],
    [ "Name", "classlab5agapov__v3_1_1_person.html#af6b895916993e3e35bb82a7d630d87c2", null ],
    [ "SubjectName", "classlab5agapov__v3_1_1_person.html#ad582f3a2a88e7aad031e6cdd435db1b1", null ]
];