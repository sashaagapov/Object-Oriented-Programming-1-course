var classlab5agapov__v1_1_1_teacher =
[
    [ "Teacher", "classlab5agapov__v1_1_1_teacher.html#aed9771c3fe893f7f26139f97533f00f0", null ],
    [ "Teacher", "classlab5agapov__v1_1_1_teacher.html#a6c30d5d99ab38130f74c327c418b313c", null ],
    [ "Teacher", "classlab5agapov__v1_1_1_teacher.html#aa4dd3713808c0804e297f99197f1bfa1", null ],
    [ "ChangeStudyHours", "classlab5agapov__v1_1_1_teacher.html#a32449ab31695ee690b1d3b2d3d9c432a", null ],
    [ "DecreaseStudents", "classlab5agapov__v1_1_1_teacher.html#ad88f6aa4acd517f40780b277a76f1328", null ],
    [ "GetInfo", "classlab5agapov__v1_1_1_teacher.html#a3c0e0697f94e5ccccfe881b0bd2c9ff0", null ],
    [ "GiveMaterial", "classlab5agapov__v1_1_1_teacher.html#a53f806474996259c9a3e570aaca87882", null ],
    [ "GradeStudent", "classlab5agapov__v1_1_1_teacher.html#a9948fcd04156178ef2a17673b3e258ab", null ],
    [ "IncreaseStudents", "classlab5agapov__v1_1_1_teacher.html#ae4075be799cdebe232d244a869273301", null ],
    [ "WriteGradeToJournal", "classlab5agapov__v1_1_1_teacher.html#a985da93f703948902b8a1311bbd71f07", null ],
    [ "gradesJournal", "classlab5agapov__v1_1_1_teacher.html#ad090007bb9d44227af38ee6b8c058ec9", null ],
    [ "quantityOfStudents", "classlab5agapov__v1_1_1_teacher.html#ac4accf524d9556dc339fe0b96a084216", null ],
    [ "studyHours", "classlab5agapov__v1_1_1_teacher.html#aaf7cff40d8805d4914479f573990e6b9", null ],
    [ "studyMaterial", "classlab5agapov__v1_1_1_teacher.html#a32f488fed2dae3356f044a0deee3afbe", null ],
    [ "DiplomaProject", "classlab5agapov__v1_1_1_teacher.html#af401425c3016a3caaa38881a85ab50d9", null ],
    [ "GradesJournal", "classlab5agapov__v1_1_1_teacher.html#affab7cc26943ff3481d695db60433ffd", null ],
    [ "QuantityOfStudents", "classlab5agapov__v1_1_1_teacher.html#a7d32b15651c95e97b000626d87dd97a5", null ],
    [ "StudyHours", "classlab5agapov__v1_1_1_teacher.html#aac0e4b90d3cfb3f12dbff9672feb7aef", null ],
    [ "StudyMaterial", "classlab5agapov__v1_1_1_teacher.html#afaea9f6fa43e34945c699dea5d3c93f9", null ],
    [ "TeacherName", "classlab5agapov__v1_1_1_teacher.html#a97282fd86db6a880594f0932846d34e8", null ]
];