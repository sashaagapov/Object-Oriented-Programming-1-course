var _student_8cs =
[
    [ "lab5agapov_v3.Student", "classlab5agapov__v3_1_1_student.html", "classlab5agapov__v3_1_1_student" ]
];