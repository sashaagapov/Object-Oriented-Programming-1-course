var namespaces_dup =
[
    [ "lab5agapov_v3", "namespacelab5agapov__v3.html", "namespacelab5agapov__v3" ]
];