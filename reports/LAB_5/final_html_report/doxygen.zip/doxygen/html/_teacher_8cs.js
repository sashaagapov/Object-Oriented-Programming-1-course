var _teacher_8cs =
[
    [ "lab5agapov_v3.Teacher", "classlab5agapov__v3_1_1_teacher.html", "classlab5agapov__v3_1_1_teacher" ]
];