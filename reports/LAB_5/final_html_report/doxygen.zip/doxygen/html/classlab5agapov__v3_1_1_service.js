var classlab5agapov__v3_1_1_service =
[
    [ "Service", "classlab5agapov__v3_1_1_service.html#abedcd4bc3f91c7835ec9c8b12f174e83", null ],
    [ "Service", "classlab5agapov__v3_1_1_service.html#a1690cd2c8216ad215700426598c7581b", null ],
    [ "Service", "classlab5agapov__v3_1_1_service.html#a6e40622f0b295fae3a4cb0eb3b6b526c", null ],
    [ "AppendProtocol", "classlab5agapov__v3_1_1_service.html#aca84185c3651588104303d39cc314802", null ],
    [ "PrintAndSave", "classlab5agapov__v3_1_1_service.html#abdca1c8de4671502b32842e5f2c32656", null ],
    [ "PrintToConsole", "classlab5agapov__v3_1_1_service.html#a7482607239d6b15bf04b511a9764354c", null ],
    [ "ReadFromConsole", "classlab5agapov__v3_1_1_service.html#a75020df45fdb7877d9e08194688b983c", null ],
    [ "ReadFromFile", "classlab5agapov__v3_1_1_service.html#aa5f02e181e7d5e02b5d4cf893b8cf881", null ],
    [ "SaveProtocolToFile", "classlab5agapov__v3_1_1_service.html#a884c758be40d78f5a3cc271c7ec302fe", null ],
    [ "WriteToFile", "classlab5agapov__v3_1_1_service.html#acd071f9ff7176a26da92b7026d4980ce", null ],
    [ "dataToProcess", "classlab5agapov__v3_1_1_service.html#a33b0a454eda85894024dab2a5890790a", null ],
    [ "filePath", "classlab5agapov__v3_1_1_service.html#a079359e8b1140ab36b019866a04a4b33", null ],
    [ "outputFormat", "classlab5agapov__v3_1_1_service.html#ab30a8ccbf91e94dfb5a79455b7b8df25", null ],
    [ "protocol", "classlab5agapov__v3_1_1_service.html#ac3ecd704cafdee3e57b2dc04dc264271", null ],
    [ "DataToProcess", "classlab5agapov__v3_1_1_service.html#aa06c4eb13018adad34af2183a913045e", null ],
    [ "FilePath", "classlab5agapov__v3_1_1_service.html#a326cc92c23235f4a11185bd705b4cd14", null ],
    [ "OutputFormat", "classlab5agapov__v3_1_1_service.html#ab6727579943c4370d254e9db5f469d57", null ]
];