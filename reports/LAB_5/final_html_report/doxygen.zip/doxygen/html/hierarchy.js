var hierarchy =
[
    [ "lab5agapov_v3.DiplomaProject", "classlab5agapov__v3_1_1_diploma_project.html", null ],
    [ "lab5agapov_v3.Menu", "classlab5agapov__v3_1_1_menu.html", null ],
    [ "lab5agapov_v3.Person", "classlab5agapov__v3_1_1_person.html", [
      [ "lab5agapov_v3.Student", "classlab5agapov__v3_1_1_student.html", null ],
      [ "lab5agapov_v3.Teacher", "classlab5agapov__v3_1_1_teacher.html", null ]
    ] ],
    [ "lab5agapov_v3.Program", "classlab5agapov__v3_1_1_program.html", null ],
    [ "lab5agapov_v3.Service", "classlab5agapov__v3_1_1_service.html", null ],
    [ "lab5agapov_v3.StudentGroup", "classlab5agapov__v3_1_1_student_group.html", null ]
];