var classlab5agapov__v1_1_1_diploma_project =
[
    [ "DiplomaProject", "classlab5agapov__v1_1_1_diploma_project.html#ab6855edcc4802db487195e869f9c698f", null ],
    [ "DiplomaProject", "classlab5agapov__v1_1_1_diploma_project.html#a4cba60a7c20a983d8e901502b4785b90", null ],
    [ "GetInfo", "classlab5agapov__v1_1_1_diploma_project.html#ad44724a52d7710875b320111ba4cbe4c", null ],
    [ "AlgorithmsCount", "classlab5agapov__v1_1_1_diploma_project.html#a6151e8bfa6b90fb4941fd61220fbe5f9", null ],
    [ "Difficulty", "classlab5agapov__v1_1_1_diploma_project.html#aabb492fa04b38bfa712a19e5d6d65162", null ],
    [ "Mark", "classlab5agapov__v1_1_1_diploma_project.html#a07100c5dc24ef5b6fcd86f736995c999", null ],
    [ "SupervisorName", "classlab5agapov__v1_1_1_diploma_project.html#aad349304e170ed44e93aaf76c051fd83", null ],
    [ "ThemeName", "classlab5agapov__v1_1_1_diploma_project.html#a698bab337d05561cdb9e7b4d206a7348", null ]
];