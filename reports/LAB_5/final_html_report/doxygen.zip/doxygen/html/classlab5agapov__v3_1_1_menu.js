var classlab5agapov__v3_1_1_menu =
[
    [ "PrintOptions", "classlab5agapov__v3_1_1_menu.html#ac40a5bd593865d133d9cee4e75e7f18e", null ],
    [ "ReadCommand", "classlab5agapov__v3_1_1_menu.html#a4e8e253b8ab9973aacc042a8da90e2a2", null ]
];