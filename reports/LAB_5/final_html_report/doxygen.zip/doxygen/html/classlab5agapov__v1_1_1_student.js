var classlab5agapov__v1_1_1_student =
[
    [ "Student", "classlab5agapov__v1_1_1_student.html#a19080de198ff356dff0b0216d2f27ba9", null ],
    [ "Student", "classlab5agapov__v1_1_1_student.html#a328cabce0a7fd3cf7bb79e9cabfa3429", null ],
    [ "Student", "classlab5agapov__v1_1_1_student.html#ac7344c9ee7ada624dd822c0feb42bd2e", null ],
    [ "AddGrade", "classlab5agapov__v1_1_1_student.html#ab6a9a7713db833f7ff0ad9706170f61c", null ],
    [ "CalculateRating", "classlab5agapov__v1_1_1_student.html#a8eb56c64640700d238c405698c7788d7", null ],
    [ "DownloadMaterial", "classlab5agapov__v1_1_1_student.html#a652fb7cbc6f00d055cf1a04cc81a322e", null ],
    [ "GetInfo", "classlab5agapov__v1_1_1_student.html#ae75d97c0d4c80a8a5a6ae4bb3631069c", null ],
    [ "ViewGrades", "classlab5agapov__v1_1_1_student.html#a95363eabb9addfce8073291db32fbd5f", null ],
    [ "downloadedMaterial", "classlab5agapov__v1_1_1_student.html#ab48e8e5f9a3082d0e9d3773617f2a39e", null ],
    [ "gradesList", "classlab5agapov__v1_1_1_student.html#a0705a3fb06ee569dced7c22d03ebb54a", null ],
    [ "rating", "classlab5agapov__v1_1_1_student.html#ad57e57bd7d5aed1b4f504af1c6648f61", null ],
    [ "tasksDone", "classlab5agapov__v1_1_1_student.html#ad52aed1b7a0f85cd677436142c23e5be", null ],
    [ "DiplomaProject", "classlab5agapov__v1_1_1_student.html#a0ba0464a2712d8cf6e745f5630e1bab1", null ],
    [ "DownloadedMaterial", "classlab5agapov__v1_1_1_student.html#a066d1aa054143efd6dfb10b49f1f1eb5", null ],
    [ "GradesList", "classlab5agapov__v1_1_1_student.html#a68bc066392e1324b075cbcd8d56d9a0e", null ],
    [ "Rating", "classlab5agapov__v1_1_1_student.html#a8bdbda7b84e5cfe02150c77baa120b77", null ],
    [ "StudentName", "classlab5agapov__v1_1_1_student.html#a320f5a017cfb7849b09a197a02d0f8ce", null ],
    [ "TasksDone", "classlab5agapov__v1_1_1_student.html#a4b6745e13126cf70bb889331e02d73e4", null ]
];