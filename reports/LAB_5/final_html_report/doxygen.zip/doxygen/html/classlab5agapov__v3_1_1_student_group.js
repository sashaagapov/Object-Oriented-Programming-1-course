var classlab5agapov__v3_1_1_student_group =
[
    [ "StudentGroup", "classlab5agapov__v3_1_1_student_group.html#abaf0f0c3cd31206d180e2d0a14ff3f65", null ],
    [ "AddStudent", "classlab5agapov__v3_1_1_student_group.html#adb1d155997ca63c5189e41beccb36a85", null ],
    [ "GetInfo", "classlab5agapov__v3_1_1_student_group.html#a4ff85ebb696b85b630eb21bf1a0aebea", null ],
    [ "students", "classlab5agapov__v3_1_1_student_group.html#a576b5a336aa377d895e83fea6e325b45", null ],
    [ "Count", "classlab5agapov__v3_1_1_student_group.html#a18806dab268c72e5dcfbfd30e07a7a55", null ],
    [ "this[int index]", "classlab5agapov__v3_1_1_student_group.html#addb2327eb3046defafbbe11904a0b994", null ]
];