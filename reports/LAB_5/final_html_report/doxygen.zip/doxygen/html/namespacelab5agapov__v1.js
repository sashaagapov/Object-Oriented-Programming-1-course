var namespacelab5agapov__v1 =
[
    [ "DiplomaProject", "classlab5agapov__v1_1_1_diploma_project.html", "classlab5agapov__v1_1_1_diploma_project" ],
    [ "Menu", "classlab5agapov__v1_1_1_menu.html", "classlab5agapov__v1_1_1_menu" ],
    [ "Person", "classlab5agapov__v1_1_1_person.html", "classlab5agapov__v1_1_1_person" ],
    [ "Program", "classlab5agapov__v1_1_1_program.html", "classlab5agapov__v1_1_1_program" ],
    [ "Service", "classlab5agapov__v1_1_1_service.html", "classlab5agapov__v1_1_1_service" ],
    [ "Student", "classlab5agapov__v1_1_1_student.html", "classlab5agapov__v1_1_1_student" ],
    [ "Teacher", "classlab5agapov__v1_1_1_teacher.html", "classlab5agapov__v1_1_1_teacher" ]
];