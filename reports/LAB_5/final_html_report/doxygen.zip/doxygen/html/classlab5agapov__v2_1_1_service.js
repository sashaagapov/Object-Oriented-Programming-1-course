var classlab5agapov__v2_1_1_service =
[
    [ "Service", "classlab5agapov__v2_1_1_service.html#a1112daba8883615c20a0b42ef6d67fd2", null ],
    [ "Service", "classlab5agapov__v2_1_1_service.html#a78ba3e054fa9f41c603d11366143fb0e", null ],
    [ "Service", "classlab5agapov__v2_1_1_service.html#a3eee5c580758dcb7a45eb46ba85b8256", null ],
    [ "PrintAndSave", "classlab5agapov__v2_1_1_service.html#aba316fcfd0b649755d75404c2c35dafa", null ],
    [ "PrintToConsole", "classlab5agapov__v2_1_1_service.html#abf45321cd22fdad84ed214cda420e3ca", null ],
    [ "ReadFromConsole", "classlab5agapov__v2_1_1_service.html#aadbc80113fc4c4cbf3dfe5a370992d6f", null ],
    [ "ReadFromFile", "classlab5agapov__v2_1_1_service.html#a75772c8c44891d8ae1fd106d08ba2fcd", null ],
    [ "SaveProtocolToFile", "classlab5agapov__v2_1_1_service.html#a4f597e911fb9fd2ed0398d92916c1d0c", null ],
    [ "SaveReport", "classlab5agapov__v2_1_1_service.html#a6886bdf79f15211d5437f1097c3c14a8", null ],
    [ "dataToProcess", "classlab5agapov__v2_1_1_service.html#a632bdd516391f2144a3a6930b271c8d3", null ],
    [ "filePath", "classlab5agapov__v2_1_1_service.html#ab9dcd73d53db5b23aa1f7c3eaa94f7ca", null ],
    [ "outputFormat", "classlab5agapov__v2_1_1_service.html#a15a2dad564d277596a569923e1a88836", null ],
    [ "protocol", "classlab5agapov__v2_1_1_service.html#a7968a419b575ee5ddc96b9c94cc483b1", null ],
    [ "DataToProcess", "classlab5agapov__v2_1_1_service.html#af5922174456f55ff37341ef31f90d69b", null ],
    [ "FilePath", "classlab5agapov__v2_1_1_service.html#ae6d4a886aa2f60d456858517932b667b", null ],
    [ "OutputFormat", "classlab5agapov__v2_1_1_service.html#a0876ced4136c70c99856aa5f44dcbf5d", null ]
];