var _menu_8cs =
[
    [ "lab5agapov_v3.Menu", "classlab5agapov__v3_1_1_menu.html", "classlab5agapov__v3_1_1_menu" ]
];