var classlab5agapov__v2_1_1_person =
[
    [ "Person", "classlab5agapov__v2_1_1_person.html#a1c54487d60c8be129cea3278c4ded8b7", null ],
    [ "Person", "classlab5agapov__v2_1_1_person.html#a989b56330788ec6a4c46dbab8a67dc85", null ],
    [ "Person", "classlab5agapov__v2_1_1_person.html#a7775cadb2ae48bf35a8758665782c189", null ],
    [ "GetInfo", "classlab5agapov__v2_1_1_person.html#a00781f30360f22179a44fce595a22b01", null ],
    [ "name", "classlab5agapov__v2_1_1_person.html#a0dcb73f499521b47aad5a641a719c72a", null ],
    [ "subjectName", "classlab5agapov__v2_1_1_person.html#a5018d6fe6c2fd6642db5777db2ca378e", null ],
    [ "Name", "classlab5agapov__v2_1_1_person.html#a8fb5ddcd89f1e8b69ae17e8d86807ff0", null ],
    [ "SubjectName", "classlab5agapov__v2_1_1_person.html#ae69f967389bc903d842f78f229b5e451", null ]
];